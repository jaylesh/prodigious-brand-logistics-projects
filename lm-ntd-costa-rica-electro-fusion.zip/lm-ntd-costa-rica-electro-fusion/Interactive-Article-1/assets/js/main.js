$(document).ready(function () {


    //Global Variables
    var imageArr = [];  //insert all images in this array to preload
    var imagesPath = "assets/img/";
    var intervalToPlayAnim;
    var browserType = "desktop_curve";
    var isAnimCurveDone = false;


    //to delete
    $('.wrapper').hide();


    checkBrowserSize();

    //loading images
    var Progress = {
        bar: null,
        index: 0,
        imgList: [],
        init: function () {
            var box = document.getElementById("progressBox");
            var prog = document.createElement("progress");
            box.appendChild(prog);
            this.bar = prog;
        },

        loadImages: function (paths) {
            var self = this,
                i, length = paths.length;

            for (i = 0; i < length; i++) {
                var img = new Image();
                img.onload = function () {
                    self.increase();
                    if (self.index >= length) {
                        self.done();
                    }
                };
                img.src = paths[i];
                this.imgList.push(img);
            }
        },

        increase: function () {
            this.index++;
            var preloaderNUmb = parseInt((100 / imageArr.length) * this.index);
            $('.num').text(preloaderNUmb + '%');
            $(".loading-page hr").css("width", preloaderNUmb + "%");
        },

        done: function () {
            $('.wrapper-preloader').hide();
            $('.wrapper').fadeIn();
            showCurvesAnimation();

        }
    };

    getAllImages();
    Progress.loadImages(imageArr);

    window.addEventListener('resize', checkBrowserSize);

    function checkBrowserSize() {

        if (window.innerWidth >= 1024) {
            browserType = "desktop_curve";
        }
        else {
            browserType = "mobile_curve";
        }

        if (window.innerWidth >= 568 && window.innerWidth <= 812 && window.matchMedia("(orientation: landscape)")) {
            browserType = "desktop_curve";
        }

        if (isAnimCurveDone) {
            $('.graphic-line').attr('src', imagesPath + browserType + "/lines_23.png");
        }
    }

    function getAllImages() {
        for (var i = 1; i <= 23; i++) {
            imageArr.push(imagesPath + browserType + "/lines_" + i + ".png");
        }

        for (var i = 1; i <= 8; i++) {
            imageArr.push(imagesPath + "splash/" + i + ".png");
        }
    }

    function showCurvesAnimation() {
        var lineAnimNum = 1;

        intervalToPlayAnim = setInterval(function () {

            if (lineAnimNum <= 23) {
                $('.graphic-line').attr('src', imagesPath + browserType + "/lines_" + lineAnimNum + ".png");
                lineAnimNum++
            }
            else {
                clearInterval(intervalToPlayAnim);
                isAnimCurveDone = true;
            }
        }, 50);
    }


    $(".switch-onclick").click(function (e) {
        $(".splash-container").fadeIn();
        $(".glitter").fadeIn();
        $(".graphic-1").addClass("graphic-mob");
        $(".graphic-2").addClass("graphic-desktop");
        $(".splash-container").css("visibility", "visible");
        $(".hand-icon").fadeOut(300);

        clickHandler();
    });


    function clickHandler() {

        var tl = gsap.timeline({onComplete: disolveSplash});
        tl.to(".splash-8", {duration: 0.6, scale: 1});
        tl.to(".splash-7", {duration: 0.6, scale: 1, rotation: 0}, '-=0.5');
        tl.to(".splash-6", {duration: 0.6, scale: 1, rotation: 0}, '-=0.5');
        tl.to(".splash-5", {duration: 0.4, scale: 1, opacity: 1}, '-=0.4');
        tl.to(".splash-4", {duration: 0.4, scale: 1, opacity: 1}, '-=0.3');
        tl.to(".splash-3", {duration: 0.4, scale: 1, opacity: 1}, '-=0.3');
        tl.to(".splash-2", {duration: 0.4, scale: 1, opacity: 1}, '-=0.3');
        tl.to(".splash-1", {duration: 0.4, scale: 1, opacity: 1}, '-=0.3');
    }

    function disolveSplash() {
        var tl2 = gsap.timeline();
        var durationEnd = 0.3;

        tl2.to((".splash-8,.splash-6,.splash-3"), {duration: durationEnd, opacity: 0}).delay(2);
        tl2.to((".splash-7,.splash-2,.splash-5"), {duration: durationEnd, opacity: 0}, '-=0.2');
        tl2.to((".splash-4,.splash-1"), {duration: durationEnd, opacity: 0}, '-=0.2');
        tl2.to(".glitter", {duration: 0.8, opacity: 0}, '-=0.3');
        tl2.to(".cig-pack", {duration: 0.8, opacity: 0}, '-=0.8');
        tl2.to((".graphic-desktop,.graphic-mob"), {duration: 0.8, opacity: 0}, '-=0.8');
        tl2.to((".graphic-desktop,.graphic-mob"), {duration: 0.8, opacity: 0}, '-=0.8');
        tl2.to((".background-two-layer_img1,.background-two-layer_img2"), {duration: 0.8, opacity: 1}, '-=0.8');
        tl2.to(".bloc-text-a", {duration: 0.8, opacity: 0}, '-=0.8');
        tl2.to(".bloc-text-a", {duration: 0, display: 'none'});
        tl2.to(".bloc-text-b", {duration: 0, display: 'block'});
        tl2.to(".bloc-text-b", {duration: 0.8, opacity: 1}, '-=0.0');

        $(".switch-onclick").off();
    }

});