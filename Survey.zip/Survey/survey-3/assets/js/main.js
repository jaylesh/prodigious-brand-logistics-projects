$(document).ready(function() {
    $("[data-localize]").localize("assets/json/survey.json", { language: "fr" });
    var elem = $('#survey-3');
    var survey = new Survey(elem);
});