(function(w,$){

    function Survey(elem, options){
       this.el = elem;
       this.slideIndex = 0;
       this.question = "";
       this.answer = "";
       this.data = [];
       this.sequenceElement = this.el.find('#sequence')[0];
       this.malborosequence;
       this.options = $.extend({
           cycle: false,
           swipeNavigation: false
       }, options);

       this.init();
    }

    // Quiz Initialization
    Survey.prototype.init = function() {
        this.initCarousel();
        this.buttonClickEvent();
    };

    //create quiz carousel
    Survey.prototype.initCarousel = function(){
        this.malborosequence = sequence(this.sequenceElement , this.options);
        this.noOfSlides = this.malborosequence.noOfSteps;
    };

    // Move to next slide
    Survey.prototype.next = function(){
        this.malborosequence.next();
    };

    // Get question
    Survey.prototype.getQuestion = function(event) {
        var previousSlide = this.el.find('li')[this.slideIndex]; // previous slide
        this.question = $(previousSlide).find('h2').text();
    };

    // Set previous slide index
    Survey.prototype.setSlideIndex = function() {
        this.slideIndex = $('.seq-in').index();
    };

    // Get answer (text button)
    Survey.prototype.setButtonClickText= function(event) {
        this.answer = $(event.target).text();
    };

    // Get survey slide infos
    Survey.prototype.getSurveyInfos = function(event) {
        this.getQuestion(event);
        this.setButtonClickText(event);
    };

    // Check if last slide button is clicked
    Survey.prototype.isNextClickLastSlide = function() {
        return this.noOfSlides === (this.slideIndex + 1);
    };

    //send info to DB
    Survey.prototype.sendSurveyInfos = function(){
        // ajax call
        // redirect to leaderboard
        if (this.isNextClickLastSlide()) {
            console.log(this.data);
        }
    };

    // push survey infos to data array
    Survey.prototype.setSurveyInfos = function(){
        this.data[this.slideIndex] = ({"question": this.question, "answer": this.answer});
    };

    // Execute functions on yes/no button event click
    Survey.prototype.buttonClickEvent = function() {
        var _ = this;
        $(".yes, .no").on('click', function(ev) {
            _.next();
            _.setSlideIndex();
            _.getSurveyInfos(ev);
            _.setSurveyInfos(ev);
            _.sendSurveyInfos(ev);
        });
    };

    w.Survey =  Survey;
})(window, $);
