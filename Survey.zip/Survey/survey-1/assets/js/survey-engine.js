(function(w,$){

    function Survey(elem, options){
       this.el = elem;
       this.parentContainer;
       this.noOfSlides;
       this.slideIndex = 0;
       this.data = [];
       this.sequenceElement = this.el.find('#sequence')[0];
       this.malborosequence;
       this.options = $.extend({
           cycle: false,
           swipeNavigation: false
       }, options);

       this.init();
    }

    // Quiz Initialization
    Survey.prototype.init = function() {
        this.initCarousel();
        this.buttonClickEvent();
        this.ratingClickEvent();
    };

    //create quiz carousel
    Survey.prototype.initCarousel = function(){
        this.malborosequence = sequence(this.sequenceElement , this.options);
        this.noOfSlides = this.malborosequence.noOfSteps;
    };

    // Next/Prev slide button click event
    Survey.prototype.buttonClickEvent = function() {
        var _ = this;
        $('#next, #prev').on('click', function(ev) {

            if (ev.currentTarget.id === 'next') {

                _.malborosequence.next();
                _.disableElems($('button'), true);
                _.isLastSlideButtonClick() ? _.sendRating() : '';

            } else {

                _.malborosequence.prev();
                _.disableElems($('button'), false);
            }

            _.ratingsIsChecked();
        });
    };

    // Check if last slide button is click
    Survey.prototype.isLastSlideButtonClick = function() {
        return this.noOfSlides === this.slideIndex;
    };

    // trigger when slide changes
    Survey.prototype.ratingsIsChecked = function() {
        var _ = this;
        this.malborosequence.nextPhaseStarted = function(id, sequence) {
            var activeSlide = sequence.$steps[parseInt(id) - 1];
            var isChecked = $(activeSlide).find('.ratings').hasClass('checked');

            if (isChecked) {
                _.disableElems($('button'), false);
            }
        }
    };

    //send info to DB
    Survey.prototype.sendRating = function(){
        // ajax call
        console.log(this.data);
    };

    //adding user score
    Survey.prototype.pushRating = function(obj){
        this.data[obj.question] = obj.ratings;
        console.log(this.data);
    };

    // Event on click rating
    Survey.prototype.ratingClickEvent = function(){

        var _ = this;

        this.el.find('.svg-rating').on('click', function() {

            _.slideIndex = ($(this).closest('li').index() + 1);
            _.disableElems($('button'), false);
            _.parentContainer = $(this).parent('.ratings');
            _.parentContainer.addClass('checked'); // Checked ratings

            var checkedStarPos = $(this).index() + 1;
            var noOfStarsClicked = _.parentContainer.find('path').slice(0, checkedStarPos);

            _.updateRating();
            _.pushRating({ question: _.getQuestion() , ratings: noOfStarsClicked.length });

            noOfStarsClicked.css('fill', 'orange');
        });
    };

    // Get question
    Survey.prototype.getQuestion = function() {
        return this.parentContainer.closest('.content').find('.question').text();
    };

    // Change star to grey
    Survey.prototype.updateRating = function() {
        this.parentContainer.find('path').css('fill', 'grey');
    };

    // Disable/Enable elements
    Survey.prototype.disableElems = function(elem, disableBool) {
        this.el.find(elem).attr('disabled', disableBool);
    };

    w.Survey =  Survey;
})(window, $);
