// JavaScript Document

$(document).ready(function () {

    var myElement = document.getElementsByClassName('wrapper');
    var alphabetArray = genCharArray('A', 'Z');
    var hasClick = false;
    var previousElementTouched = "";
    var elementBeforeLeave = ""
    var selectedElementsArr = [];
    var randomPredifArr = 0;
    var wordMatch = ["explorer", "player", "master", "collector"];
    var predifWord = [
        [
            [13, "E"],
            [22, "X"],
            [31, "P"],
            [40, "L"],
            [49, "O"],
            [58, "R"],
            [67, "E"],
            [76, "R"]
        ], [
            [106, "P"],
            [105, "L"],
            [104, "A"],
            [103, "Y"],
            [102, "E"],
            [101, "R"]
        ], [
            [46, "M"],
            [37, "A"],
            [28, "S"],
            [19, "T"],
            [10, "E"],
            [1, "R"]
        ], [
            [99, "C"],
            [91, "O"],
            [83, "L"],
            [75, "L"],
            [67, "E"],
            [59, "C"],
            [51, "T"],
            [43, "O"],
            [35, "R"]
        ]
    ];

    var predifWord3 = [
        [
            [16, "E"],
            [25, "X"],
            [34, "P"],
            [43, "L"],
            [52, "O"],
            [61, "R"],
            [70, "E"],
            [79, "R"]
        ], [
            [73, "P"],
            [64, "L"],
            [55, "A"],
            [46, "Y"],
            [37, "E"],
            [28, "R"]
        ], [
            [14, "M"],
            [13, "A"],
            [12, "S"],
            [11, "T"],
            [10, "E"],
            [9, "R"]
        ], [
            [99, "C"],
            [100, "O"],
            [101, "L"],
            [102, "L"],
            [103, "E"],
            [104, "C"],
            [105, "T"],
            [106, "O"],
            [107, "R"]
        ]
    ];

    var predifWord2 = [
        [
            [16, "E"],
            [15, "X"],
            [14, "P"],
            [13, "L"],
            [12, "O"],
            [11, "R"],
            [10, "E"],
            [9, "R"]
        ], [
            [47, "P"],
            [48, "L"],
            [49, "A"],
            [50, "Y"],
            [51, "E"],
            [52, "R"]
        ], [
            [99, "M"],
            [100, "A"],
            [101, "S"],
            [102, "T"],
            [103, "E"],
            [104, "R"]
        ], [
            [18, "C"],
            [28, "O"],
            [38, "L"],
            [48, "L"],
            [58, "E"],
            [68, "C"],
            [78, "T"],
            [88, "O"],
            [98, "R"]
        ]
    ];


    var predifWord4 = [
        [
            [100, "E"],
            [101, "X"],
            [102, "P"],
            [103, "L"],
            [104, "O"],
            [105, "R"],
            [106, "E"],
            [107, "R"]
        ], [
            [37, "P"],
            [46, "L"],
            [55, "A"],
            [64, "Y"],
            [73, "E"],
            [82, "R"]
        ], [
            [63, "M"],
            [55, "A"],
            [47, "S"],
            [39, "T"],
            [31, "E"],
            [23, "R"]
        ], [
            [8, "C"],
            [17, "O"],
            [26, "L"],
            [35, "L"],
            [44, "E"],
            [53, "C"],
            [62, "T"],
            [71, "O"],
            [80, "R"]
        ]
    ];

    var predifWord5 = [
        [
            [73, "E"],
            [65, "X"],
            [57, "P"],
            [49, "L"],
            [41, "O"],
            [33, "R"],
            [25, "E"],
            [17, "R"]
        ], [
            [40, "P"],
            [49, "L"],
            [58, "A"],
            [67, "Y"],
            [76, "E"],
            [85, "R"]
        ], [
            [60, "M"],
            [69, "A"],
            [78, "S"],
            [87, "T"],
            [96, "E"],
            [105, "R"]
        ], [
            [9, "C"],
            [10, "O"],
            [11, "L"],
            [12, "L"],
            [13, "E"],
            [14, "C"],
            [15, "T"],
            [16, "O"],
            [17, "R"]
        ]
    ];


    var random_predifWord = [predifWord, predifWord2, predifWord3, predifWord4, predifWord5];

// device detection
    if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent)
        || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0, 4))) {
        isMobile = true;
    }

    $(".wrapper").bind("touchmove", function (e) {
        e.preventDefault();
    });


    hammertime = new Hammer(myElement[0]);

    hammertime.get('swipe').set({direction: Hammer.DIRECTION_HORIZONTAL});
    // hammertime.on("swipeleft swiperight", onSwipeAction);


    randomAlphabet();

    // checkIfMatch();

    function checkIfMatch() {

        console.log(selectedElementsArr)
        var word = "";

        for (var j = 0; j < selectedElementsArr.length; j++) {
            word = word + $('#' + selectedElementsArr[j]).html().split('<div class="to-hover"></div>')[0].toLowerCase();
        }

        console.log(word)

        for (var i = 0; i < wordMatch.length; i++) {
            if (wordMatch[i] == word) {
                console.log("found = ", wordMatch[i]);
                $("." + wordMatch[i] + "-" + (randomPredifArr + 1)).show();
            }
        }
    }

    function addListeners() {
        $('.to-hover').on('mousedown touchstart', function () {
            console.log('wawa')
            hasClick = true;
            var $element = $(this).parent();

            if (hasClick) {
                if ($element.hasClass('selected')) {
                    $element.removeClass('selected');
                }
                else {
                    $element.addClass('selected');
                    selectedElementsArr.push($element.attr('id'))
                    console.log($element.attr('id'))
                }
            }
        });

        $('.wrapper').on("mouseleave", reset)

        $('.to-hover').on('mouseup touchend', reset);

        $('.to-hover').on('mouseover', function (event) {
            /*  var myLocation = event.originalEvent.changedTouches[0];
              var realTarget = document.elementFromPoint(myLocation.clientX, myLocation.clientY);
  */
            var $element = $(this).parent();

            if (hasClick) {
                if ($element.hasClass('selected')) {
                    console.log("test");
                    selectedElementsArr.pop();
                    // $(this).removeClass('selected');

                    // $(realTarget).removeClass('selected');

                }
                else {
                    $element.addClass('selected');
                    console.log($element.html());

                    selectedElementsArr.push($element.attr('id'));
                    // $(realTarget).html();
                    // $(realTarget).addClass('selected');
                    //  console.log($(realTarget).html())
                }

                makeSelectionDeselection(selectedElementsArr);
            }


        });

        $('.to-hover').on('touchmove', function (event) {
            var myLocation = event.originalEvent.changedTouches[0];
            var theTarget = document.elementFromPoint(myLocation.clientX, myLocation.clientY);
            var realTarget = $(theTarget).parent();
            var realTargetID = $(realTarget).attr('id');


            if (hasClick && previousElementTouched.id != realTargetID) {

                if ($(realTarget).hasClass('selected') && (previousElementTouched.id != realTargetID)) {
                    handleSelectedElements($(previousElementTouched).attr('id'));
                    previousElementTouched = realTarget;
                }
                else if (!$(realTarget).hasClass('selected') && $(realTarget).hasClass('square')) {
                    selectedElementsArr.push(realTargetID);
                }

                selectedElementsArr = unique(selectedElementsArr);

                for (var i = 0; i < selectedElementsArr.length; i++) {
                    if (realTargetID == selectedElementsArr[i] && (i < selectedElementsArr.length - 1)) {
                        selectedElementsArr.pop();
                    }
                }
                makeSelectionDeselection(selectedElementsArr);


            }


        });
    }

    function reset() {
        hasClick = false;
        $('.square').removeClass('selected')
        checkIfMatch();
        selectedElementsArr = [];
    }

    function makeSelectionDeselection(list) {
        $('.square').removeClass('selected');
        for (var i = 0; i < list.length; i++) {
            $('#' + list[i]).addClass('selected');
        }
    }

    function unique(list) {
        var result = [];
        $.each(list, function (i, e) {
            if ($.inArray(e, result) == -1) result.push(e);
        });
        return result;
    }

    function handleSelectedElements(el) {
        // selectedElementsArr.splice( $.inArray("alpha-1", selectedElementsArr), 1 );
        console.log("el", el)
        /* var result = selectedElementsArr.filter(function(elem){
              elem != el;
         });*/

        /* selectedElementsArr = $.grep(selectedElementsArr, function(value) {
             return value != el;
         });

         console.log(selectedElementsArr)*/

    }

    function genCharArray(charA, charZ) {
        var a = [], i = charA.charCodeAt(0), j = charZ.charCodeAt(0);
        for (; i <= j; ++i) {
            a.push(String.fromCharCode(i));
        }
        return a;
    }

    function getWordAndId() {
        var wordArray = [];
        var predifWord_ = random_array(random_predifWord);

        for (var a = 0; a < 4; a++) {
            // wordArray = predifWord[a];
            wordArray = predifWord_[a];

            for (var j = 0; j < 4; j++) {
                for (var i = 0; i < wordArray.length; i++) {

                    $('#alpha-' + wordArray[i][0]).html(wordArray[i][1] + "<div class='to-hover'></div>")
                }
            }
        }

    }


    function randomAlphabet() {
        var randomItem = alphabetArray[Math.floor(Math.random() * alphabetArray.length)];

        for (var i = 0; i < 117; i++) {
            // $('.wrapper').append("<div id='alpha-"+i+"' class='square'>"+i+"</div>")
            $('.wrapper').append("<div id='alpha-" + i + "' class='square'>" + alphabetArray[Math.floor(Math.random() * alphabetArray.length)] + "<div class='to-hover'></div></div>")
        }

        getWordAndId();
        addListeners();
    }

    function random_array(arr) {
        randomPredifArr = Math.floor(Math.random() * arr.length);
        console.log(randomPredifArr)

        return arr[randomPredifArr];

    }

    //testing for click

    $(".screen-1").click(function () {  //use a class, since your ID gets mangled
        $(this).addClass("slide-bloc");      //add the class to the clicked element

        console.log(onclick)
    });
});

