window.onload = function(){
var tl = new TimelineMax();




tl.to(".banner-3 #background", 2, { ease: Power1.easeOut, opacity:1, left:0});
tl.to(".banner-3 #textstack", 1, { ease: Power1.easeOut, opacity:1, top:9}, "-=1");
tl.to( ".banner-3 #logo-landscape", 1, { ease: Power1.easeOut, opacity:1, top:180}, "-=0.5");

}



