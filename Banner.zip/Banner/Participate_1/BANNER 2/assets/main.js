window.onload = function(){
var tl = new TimelineMax();




tl.to(".banner-2 #background", 2, { ease: Power1.easeOut, opacity:1, bottom:0});
tl.to(".banner-2 #textstack-1", 1, { ease: Power1.easeOut, opacity:1}, "-=1");
tl.to(".banner-2 #textstack-2", 1, { ease: Power1.easeOut, opacity:1, top:99}, "-=0.5");
tl.to(".banner-2 #logo-landscape", 1, { ease: Power1.easeOut, opacity:1, top:218}, "-=0.5");

}



