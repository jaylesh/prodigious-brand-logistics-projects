window.onload = function(){
var tl = new TimelineMax();




// tl.to("#background", 2, { ease: Power1.easeOut, opacity:1, left:0});
tl.to(".banner-4 #textstack", 1, { ease: Power1.easeOut, opacity:1, top:72});
tl.to(".banner-4 #logo-landscape", 1, { ease: Power1.easeOut, opacity:1, top:284}, "-=0.5");
tl.to(".banner-4 #cta", 1, { ease: Power1.easeOut, opacity:1, top:311});

}



