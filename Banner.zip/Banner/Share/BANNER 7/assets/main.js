window.onload = function(){
var tl = new TimelineMax();




tl.to("#background", 2, { ease: Power1.easeOut, opacity:1, bottom:0});
tl.to("#textstack", 1, { ease: Power1.easeOut, opacity:1, top:60}, "-=1");
tl.to("#logo-landscape", 1, { ease: Power1.easeOut, opacity:1, top:178}, "-=0.5");
tl.to("#cta", 1, { ease: Power1.easeOut, opacity:1, top:271});
}



