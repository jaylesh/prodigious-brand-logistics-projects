window.onload = function(){
var tl = new TimelineMax();




tl.to(".banner-6 #background", 2, { ease: Power1.easeOut, opacity:1, left:0});
tl.to(".banner-6 #textstack", 1, { ease: Power1.easeOut, opacity:1, top:13}, "-=1");
tl.to(".banner-6 #logo-landscape", 1, { ease: Power1.easeOut, opacity:1, top:109}, "-=0.5");
tl.to(".banner-6 #cta", 1, { ease: Power1.easeOut, opacity:1, top:186});
}



