window.onload = function(){
var tl = new TimelineMax();


tl.to(".banner-1 #background", 2, { ease: Power1.easeOut, opacity:1});
tl.to(".banner-1 #textstack", 1, { ease: Power1.easeOut, opacity:1, top:58}, "-=1");
tl.to(".banner-1 #logo-landscape", 1, { ease: Power1.easeOut, opacity:1, top:191}, "-=0.5");

}



