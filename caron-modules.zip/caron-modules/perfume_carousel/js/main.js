$(document).ready(function () {
    var swiperPerfume = new Swiper('.perfume-slider-container', {
        renderProgressbar: function (progressbarFillClass) {
            return '<span class="' + progressbarFillClass + '"></span>';
        },
        allowSlideNext: true,
        allowSlidePrev: true,
        loop: true,
        slidesPerView: 3,
        // If we need pagination
        pagination: {
            el: '.swiper-pagination',
            clickable: true
            // dynamicBullets: true
        },
        // Navigation arrows
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev'
        },
        // autoplay: {
        //     delay: 8000
        // },
        // speed: 2000
        breakpoints: {
            // when window width is >= 320px
            0: {
                slidesPerView: 1,
                spaceBetween: 20
            },

            320: {
                slidesPerView: 1,
                spaceBetween: 20
            },
            768: {
                slidesPerView: 2,
                spaceBetween: 20
            },
            1024: {
                slidesPerView: 3,
                spaceBetween: 20
            }
        }
    });
});