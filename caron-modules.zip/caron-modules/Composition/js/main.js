var contents = document.querySelectorAll(".fade"); 
var i = 1;
Array.prototype.forEach.call(contents, function(content) { 
      setTimeout(function() { 
          content.classList.add("fadein") }, 700*i)
i++;
})
