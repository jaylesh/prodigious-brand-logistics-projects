function openTab(evt, tabName) {

    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
  }
  
  // Get the element with id="defaultOpen" and click on it
  document.getElementById("defaultOpen").click();


  // Cart quantity increment/decrement
//   function incrementValue() {
//     var value = parseInt(document.getElementById('number').value, 10);
//     value = isNaN(value) ? 0 : value;
//     if(value<10){
//         value++;
//             document.getElementById('number').value = value;
//     }
// }

// function decrementValue() {
//     var value = parseInt(document.getElementById('number').value, 10);
//     value = isNaN(value) ? 0 : value;
//     if(value>1){
//         value--;
//             document.getElementById('number').value = value;
//     }

// }

// document.querySelectorAll('.cart-item__qty--add').forEach(function(incrementValue) {
//     incrementValue.addEventListener('click', function() {
//         var value = parseInt(document.getElementById('qty-number').value, 10);
//         value = isNaN(value) ? 0 : value;
//         if(value <= 10){
//         value++;
//             document.getElementById('qty-number').value = value;
//         }
//     });
// });


// document.querySelectorAll('.cart-item__qty--subtract').forEach(function(decrementValue) {
//     decrementValue.addEventListener('click', function() {
//         var value = parseInt(document.getElementById('qty-number').value, 10);
//         value = isNaN(value) ? 0 : value;
//         if(value > 1){
//             value--;
//             document.getElementById('qty-number').value = value;
//         }
//     });
// });



var incrementBtn = document.getElementsByClassName('cart-item__qty--add');
var decrementBtn = document.getElementsByClassName('cart-item__qty--subtract');

//Increment function
for( var i = 0; i < incrementBtn.length; i++) {
    var qtyBtn = incrementBtn[i];

    qtyBtn.addEventListener('click', function(e) {
        var buttonClicked = e.target;
        
        var qtyInput = buttonClicked.parentElement.children[1];

        var qtyInputValue = qtyInput.value;        

        var newValue = parseInt(qtyInputValue) + 1;
        
        qtyInput.value = newValue
    })
}

//Decrement function
for( var i = 0; i < decrementBtn.length; i++) {
    var qtyBtn = decrementBtn[i];

    qtyBtn.addEventListener('click', function(e) {
        var buttonClicked = e.target;
        
        var qtyInput = buttonClicked.parentElement.children[1];

        var qtyInputValue = qtyInput.value;        

        var newValue = parseInt(qtyInputValue) - 1;
        
        qtyInput.value = newValue
    })
}