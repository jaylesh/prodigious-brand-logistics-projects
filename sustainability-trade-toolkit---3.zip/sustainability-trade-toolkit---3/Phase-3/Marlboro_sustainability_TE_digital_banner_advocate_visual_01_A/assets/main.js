window.onload = function(){






var tl = new TimelineMax();



tl.to(".banner-1 #text_1", 0.5, {ease: Power1.easeOut,  opacity:1});
tl.to(".banner-1 #text_2", 0.5, { ease: Power1.easeOut, opacity:1},"-=0.2");
tl.to(".banner-1 #logo", 0.5, { ease: Power1.easeOut, opacity:1});



}



