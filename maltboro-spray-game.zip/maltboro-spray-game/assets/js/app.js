/**
 * class & method here
 */
(function () {
  var SiteEngine = function (container, options) {
    this.container = container;
    this.init(options);
    this.isActivate = false;
  };

  SiteEngine.prototype.init = function (options) {
    this.swiper = new Swiper(this.container, options);
  };

  SiteEngine.prototype.slideNext = function () {
    this.instance().slideNext();
  };

  SiteEngine.prototype.slidePrev = function () {
    this.instance().slidePrev();
  };

  SiteEngine.prototype.gotoSlideNumber = function (number, delay) {
    this.instance().slideTo(number);
  };

  SiteEngine.prototype.hide = function (el, d) {
    gsap.to(el, {
      alpha: 0,
      duration: d != null ? d : 0.35,
      onComplete: function () {
        el.style.visibility = "hidden";
      },
    });
  };

  SiteEngine.prototype.show = function (el) {
    el.style.visibility = "visible";
    gsap.to(el, {
      alpha: 1,
      duration: 0.35,
    });
  };

  SiteEngine.prototype.blur = function (o) {
    o.forEach(function (e) {
      if (e.blur) classie.add(e.el, "blur");
      else classie.remove(e.el, "blur");
    });
  };

  // getter && setters
  SiteEngine.prototype.getContainer = function () {
    return this.container;
  };
  SiteEngine.prototype.instance = function () {
    return document.querySelector(this.container).swiper;
  };
  window.SiteEngine = SiteEngine;
})(window);

/**
 * Game Engine
 */
(function () {
  const loader = PIXI.Loader.shared;
  PIXI.utils.skipHello();
  var GameEngine = function (canvas, width, height, callback) {
    this.app,
      this.stage,
      this.gameWidth,
      this.gameHeight,
      this.renderer,
      this.container,
      this.isDragging,
      this.shadow,
      (this.gameOver = false),
      (this.scale = 0.18),
      this.texture,
      this.textureSprite,
      this.brush,
      this.tool;
    this.list = [];
    this.ploader = document.querySelector(".preloader"); // preloader
    this.progressBar = this.ploader.querySelector(".progress-bar");
    this.paintProgress = document.querySelector(".paint-progress");
    this.btnNext = document.querySelector(".swiper-slide > .next");
    this.infoText;
    this.view = canvas;
    this.gameWidth = width;
    this.gameHeight = height;
    this.guide = new PIXI.Graphics();
    this.overlayBackground = new PIXI.Graphics();
    this.callback = callback;
    this.load();
  };

  GameEngine.prototype.load = function () {
    loader.add("martboro-pack", "assets/img/martboro-pack.png");
    loader.add("martboro-pack-shadow", "assets/img/martboro-pack-shadow.png");
    loader.add("background", "assets/img/game-background-red.png");
    loader.add("pencil-pack", "assets/img/pencil-pack.png");
    loader.add("spray-pack", "assets/img/spray-pack.png");
    loader.add("brush-pack", "assets/img/brush-pack.png");
    loader.add("spray-shape", "assets/img/spray_shape.png");
    loader.add("pen", "assets/img/pen.png");
    loader.add("spray", "assets/img/spray.png");
    loader.add("brush", "assets/img/brush.png");
    loader.add("pen-template", "assets/img/pen-template.png");
    loader.add("spray-template", "assets/img/spray-template.png");
    loader.add("brush-template", "assets/img/brush-template.png");
    loader.onError.add(function (e) {
      console.log(e);
    });
    loader.onProgress.add(this.progress.bind(this));
    loader.onComplete.add(this.complete.bind(this));
    loader.load();
  };

  GameEngine.prototype.progress = function (e) {
    this.progressBar.style.width = e.progress + "%";
  };

  GameEngine.prototype.complete = function (e) {
    var text = this.ploader.querySelector(".text");
    var bar = this.ploader.querySelector(".box");
    var _ = this;
    var t = gsap
      .timeline()
      .to(text, {
        x: -window.innerWidth,
        alpha: 0,
        duration: 0.6,
      })
      .to(
        bar,
        {
          x: window.innerWidth,
          alpha: 0,
        },
        "-=0.5"
      )
      .to(this.ploader, {
        alpha: 0,
        onComplete: function () {
          classie.add(bar.parentNode, "hide");
          _.init();
        },
      });
  };

  GameEngine.prototype.init = function () {
    this.app = new PIXI.Application({
      width: this.gameWidth,
      height: this.gameHeight,
      view: this.view,
      transparent: true,
      autoDensity: true,
      resolution: window.devicePixelRatio || 1,
      resizeTo: this.view.parentNode,
    });
    this.renderer = PIXI.autoDetectRenderer(this.gameWidth, this.gameHeight);
    this.stage = this.app.stage;
    this.container = new PIXI.Container();
    this.stage.addChild(this.container);
    this.mediaNoticeInfoText = document.querySelector(".media-notice-info > p");

    //guide
    this.guide.lineStyle(0); // draw a circle, set the lineStyle to zero so the circle doesn't have an outline
    this.guide.beginFill(0xdeffdd, 1);
    this.guide.drawCircle(0, 0, 1);
    this.guide.endFill();

    this.container.addChild(this.guide);
    this.pack = this.crateSpriteWithTexture("martboro-pack");
    this.shadow = this.crateSpriteWithTexture("martboro-pack-shadow");
    this.container.addChild(this.shadow);
    this.container.addChild(this.pack);

    var blurFilter = new PIXI.filters.BlurFilter();
    blurFilter.blendMode = PIXI.BLEND_MODES.MULTIPLY;
    this.shadow.filters = [blurFilter];
    this.shadow.alpha = 0.7;
    this.pack.alpha = 0.8;
  };

  GameEngine.prototype.createGame = function (pack, tool) {
    this.ovelay = this.crateSpriteWithTexture(pack);
    this.tool = this.crateSpriteWithTexture(tool, 0.6);
    this.tool.type = tool;
    this.tool.buttonMode = true;
    this.tool.interactive = true;
    this.tool.rotation = utils.degreesToRads(30);
    this.tool.pivot.set(0.5);

    if (this.ovelay) this.container.addChild(this.ovelay);

    //create texture
    this.texture = PIXI.RenderTexture.create(
      this.app.screen.width,
      this.app.screen.height
    );
    this.textureSprite = new PIXI.Sprite(this.texture);
    this.textureSprite.anchor.set(0.5);
    this.container.addChild(this.textureSprite);
    this.ovelay.mask = this.textureSprite;

    var text = document
      .querySelector(".tool." + tool)
      .getAttribute("data-text")
      .toUpperCase();
    text = text.split("|").join("\n");
    this.addText(text);
    this.setBrush(tool);
    this.onResize();
    this.start();
    this.addEvent();
    this.container.addChild(this.tool);

    var _ = this;
    window.addEventListener(
      "resize",
      debounce(function () {
        _.onResize();
      }, 1)
    );

    window.addEventListener(
      "orientationchange",
      debounce(function () {
        _.onResize();
      }, 1)
    );

    this.btnNext.addEventListener("click", this.restart.bind(this));
  };

  GameEngine.prototype.crateSpriteWithTexture = function (name, scale) {
    var instance = new PIXI.Sprite(this.getTexture(name));
    instance.anchor.set(0.5);
    instance.scale.set(scale || 0.18);
    this.scale = scale;
    instance.name = name;
    return instance;
  };

  GameEngine.prototype.addText = function (text) {
    this.infoText = new PIXI.Text(text, {
      fontFamily: "neuland_groteskcondensed_bold",
      fontSize: "2.6em",
      fill: 0x000000,
      align: "left",
    });
    this.container.addChild(this.infoText);
  };

  GameEngine.prototype.setBrush = function (name) {
    this.brush = new PIXI.Sprite(this.getTexture(name + "-template"));
    this.brush.anchor.set(0.5);
    this.brush.scale.set(1.2);
    // var size = this.tool.type == 'pen' ? 10 : ((this.tool.type == 'brush') ? 15 : 20);
    // this.brush = new PIXI.Graphics();
    // this.brush.beginFill(0xffffff);
    // this.brush.drawCircle(0, 0, size);
    // this.brush.endFill();
    // this.brush.addChild(this.brushGraphic);
    //this.container.addChild(this.brush);
  };

  GameEngine.prototype.getTexture = function (name) {
    return loader.resources[name].texture;
  };

  GameEngine.prototype.onResize = function () {
    const parent = this.view.parentNode;
    const canvas = this.view;
    var w = parent.clientWidth;
    var h = parent.clientHeight;
    this.gameWidth = w;
    this.gameHeight = h;
    canvas.style.width = w + "px";
    canvas.style.height = h + "px";
    canvas.style.objectFit = "cover";
    this.renderer.resize(w, h);

    var ratio = this.renderer.screen.width / this.renderer.screen.height;

    var or = deviceOrientation(
      this.renderer.screen.width,
      this.renderer.screen.height
    );
    this.guide.x = this.renderer.screen.width / 2;
    this.guide.y =
      or == "portrait"
        ? (this.renderer.screen.height / 1000) * 190
        : (this.renderer.screen.width / 1080) * 190;

    if (or == "portrait") {
      if (w <= 375) {
        this.pack.scale.set(0.19);
        this.tool.scale.set(0.6);
      } else {
        this.pack.scale.set(0.25);
        this.tool.scale.set(0.9);
      }
    } else {
      if (w > 414) {
        this.pack.scale.set(0.25);
        this.tool.scale.set(0.75);
        this.infoText.style.fontSize = "3em";
        this.infoText.style.wordWrapWidth = this.renderer.screen.width - 150;
        this.infoText.x =
          (this.renderer.screen.width - this.infoText.width) * 0.5;
      }
    }

    this.ovelay.scale = this.pack.scale;
    this.shadow.scale = this.pack.scale;

    if (this.pack == null) return;
    this.pack.x = this.renderer.screen.width / 2;
    this.pack.y = this.guide.y + this.pack.height / 2 - 340 * this.pack.scale.x; // red pack red triangle h

    this.ovelay.x = this.overlayBackground.x = this.textureSprite.x = this.pack.x;
    this.overlayBackground.y = this.textureSprite.y = this.pack.y;
    this.ovelay.y = this.pack.y + (this.ovelay.height / 2) * -1;
    this.textureSprite.y = this.ovelay.y;

    this.shadow.x = this.pack.x + 43;
    this.shadow.y = this.pack.y + 35;

    this.infoText.x = this.pack.x - this.pack.width / 2;
    this.infoText.y = this.pack.y + this.pack.height / 2 + 30;
    this.tool.x = this.infoText.x + this.infoText.width + this.tool.width / 2;
    this.tool.y = this.pack.y + (this.pack.height + this.tool.height) / 2; //this.infoText.y + 50;

    this.tool.oPos = {
      x: this.tool.x,
      y: this.tool.y,
    };

    this.texture = PIXI.RenderTexture.create(
      this.ovelay.width,
      this.ovelay.height
    );
    this.textureSprite.texture = this.texture;

    gsap.to(this.paintProgress, {
      width: 0 + "%",
    });
  };;;

  GameEngine.prototype.setTool = function (tool) {
    switch (tool) {
      case "pen":
        this.createGame("pencil-pack", tool);
        break;
      case "spray":
        this.createGame("spray-pack", tool);
        break;
      case "brush":
        this.createGame("brush-pack", tool);
        break;
      default:
        break;
    }
  };
  GameEngine.prototype.movesTool = function (type, o) {
    switch (type) {
      case "pen":
        gsap.to(this.tool, 0.35, {
          x: o.x + 43,
          y: o.y - 65,
        });
        break;
      case "spray":
        gsap.to(this.tool, 0.35, {
          x: o.x - 35,
          y: o.y + this.tool.width / 2 + 40,
        });
        break;
      case "brush":
        gsap.to(this.tool, 0.35, {
          x: o.x + 30,
          y: o.y - this.tool.height / 2 + 30,
        });
        break;
    }
  };

  GameEngine.prototype.start = function () {
    // this.app.ticker.stop();
    // gsap.ticker.add(this.render.bind(this));
    //this.app.ticker.add(this.render.bind(this));
  };

  GameEngine.prototype.restart = function () {
    if (this.gameOver) {
      this.callback(0);
      var _ = this;
      this.gameOver = false;
      classie.add(this.btnNext, "disabled");
      gsap.delayedCall(0.5, function () {
        _.progressBar.style.width = "0%";
        //_.container.removeChild(_.pack);
        _.container.removeChild(_.ovelay);
        // _.container.removeChild(_.shadow);
        _.container.removeChild(_.tool);
        _.container.removeChild(_.textureSprite);
        _.container.removeChild(_.infoText);
      });
    }
  };

  GameEngine.prototype.stop = function () {
    this.app.ticker.stop();
  };

  GameEngine.prototype.update = function (delta) {};

  GameEngine.prototype.render = function (delta) {
    // this.app.ticker.update();
    this.renderer.render(this.stage);
  };

  GameEngine.prototype.addEvent = function () {
    this.stage.interactive = true;
    this.stage.on("pointerdown", this.pointerDown.bind(this));
    this.stage.on("pointerup", this.pointerUp.bind(this));
    this.stage.on("pointermove", this.pointerMove.bind(this));
  };

  GameEngine.prototype.removeEvent = function () {
    this.stage.interactive = false;
    this.stage.off("pointerdown");
    this.stage.off("pointerup");
    this.stage.off("pointermove");
  };

  GameEngine.prototype.pointerDown = function (e) {
    this.isDragging = true;
    if (this.isDragging && !this.gameOver) {
      document.body.o = document.body.style.cursor;
      this.movesTool(this.tool.type, {
        x: e.data.global.x,
        y: e.data.global.y,
      });
    }
  };
  GameEngine.prototype.pointerUp = function () {
    this.isDragging = false;
    document.body.style.cursor = document.body.o;
    gsap.to(this.tool, {
      x: this.tool.oPos.x,
      y: this.tool.oPos.y,
    });
  };
  GameEngine.prototype.pointerMove = function (e) {
    if (this.isDragging && !this.gameOver) {
      const newPosition = this.textureSprite.toLocal(
        e.data.global,
        undefined,
        this.brush
      );
      this.brush.x += this.textureSprite.anchor.x * this.texture.width;
      this.brush.y += this.textureSprite.anchor.y * this.texture.height;

      this.movesTool(this.tool.type, {
        x: e.data.global.x,
        y: e.data.global.y,
      });

      var pixels = this.app.renderer.extract.pixels(this.texture);
      var count = 0;
      for (var i = 0, len = pixels.length; i < len; i += 4) {
        if (pixels[i] === 255) {
          ++count;
        }
      }
      var progress = (
        (100 * count) /
        (this.texture.width * this.texture.height)
      ).toFixed(2);
      //this.paintProgress.style.width = progress + '%';

      //console.log('Progress: ' + progress + '%');
      if (progress >= 75) {
        this.brush = new PIXI.Graphics();
        this.brush.beginFill(0xffffff);
        this.brush.drawRect(0, 0, this.ovelay.width, this.ovelay.height);
        this.brush.endFill();
        this.paintProgress.style.width = 100 + "%";
        this.isDragging = false;

        gsap.to(this.tool, {
          x: this.tool.oPos.x,
          y: this.tool.oPos.y,
          alpha: 0,
        });
        this.gameOver = true;
        progress = 100;

        this.infoText.style = new PIXI.TextStyle({
          fontFamily: "neuland_groteskcondensed_bold",
          fontSize: "1.8em",
          fill: 0x000000,
          align: "left",
          breakWords: true,
          //lineHeight: 20,
          wordWrap: true,
          wordWrapWidth: this.pack.width,
        });
        this.infoText.text = this.mediaNoticeInfoText.innerHTML.toUpperCase();
        classie.remove(this.btnNext, "disabled");
        if (this.gameWidth > 414) {
          this.infoText.style.fontSize = "3em";
          var or = deviceOrientation(
            this.renderer.screen.width,
            this.renderer.screen.height
          );
          //if (or == 'landscape') {
          this.infoText.style.wordWrapWidth = this.renderer.screen.width - 150;
          this.infoText.x =
            (this.renderer.screen.width - this.infoText.width) * 0.5;
          // }
          //this.infoText.style.lineHeight = 40;
        }
      }

      gsap.to(this.paintProgress, {
        width: progress + "%",
      });
      this.app.renderer.render(this.brush, this.texture, false, null, false);
    }
  };

  window.GameEngine = GameEngine;
})(window);

function deviceOrientation(w, h) {
  return h > w ? "portrait" : "landscape";
}

function calculateAspectRatioFit(srcWidth, srcHeight, maxWidth, maxHeight) {
  var ratio = Math.min(maxWidth / srcWidth, maxHeight / srcHeight);
  return {
    width: srcWidth * ratio,
    height: srcHeight * ratio,
  };
}

/**
 * loader
 */
window.addEventListener("load", function () {
  //parent
  const parent = new SiteEngine(".swiper-container", {
    allowTouchMove: false,
    direction: "horizontal",
  });
  const swiperParent = parent.instance();
  const swipeBtnStart = document
    .querySelector(parent.getContainer())
    .querySelector(".btn.start");
  const swipeBtnNext = document
    .querySelector(parent.getContainer())
    .querySelector(".swiper-button-next--2");

  parent.instance().on("transitionEnd", function () {
    if (this.activeIndex == 0) {
    }
  });

  function animateTools() {
    var t = gsap.timeline().from(
      ".tool img",
      {
        y: 260,
        stagger: 0.1,
        duration: 1.5,
        ease: "elastic",
      },
      "+=0.1"
    );
  }

  animateTools();

  //parent.instance().slideTo(0, 0);

  // GAME
  var gameWrapper = document.querySelector(".game-container");
  var info = gameWrapper.getBoundingClientRect();
  var height = info.height;
  var width = info.width;
  var canvas = document.getElementById("game");
  const game = new GameEngine(canvas, width, height, function (slide) {
    parent.gotoSlideNumber(slide, 0);
  });
  var currentTool, currentDiv;

  var tools = Array.from(document.querySelectorAll(".tool"));
  tools.forEach(function (el) {
    el.addEventListener("click", function (e) {
      if (currentDiv != null) classie.remove(currentDiv, "selected");
      var tool = this.getAttribute("data-tool");
      currentTool = tool;
      currentDiv = this;
      classie.add(this, "selected");
      gsap.to(this, 0.5, {
        alpha: 1,
      });

      for (var index = 0; index < tools.length; index++) {
        var element = tools[index];
        if (element != currentDiv) {
          gsap.to(element, 0.5, {
            alpha: 0.8,
          });
        }
      }
      classie.remove(swipeBtnStart, "disabled");
    });
  });

  //start btn
  swipeBtnStart.addEventListener("click", function (e) {
    if (currentTool != null) {
      gsap.delayedCall(0.2, function () {
        classie.remove(currentDiv, "selected");
        parent.gotoSlideNumber(1);
        game.setTool(currentTool);
        classie.add(swipeBtnStart, "disabled");
        currentTool = null;
      });
    }
    e.preventDefault();
    e.stopPropagation();
  });

  // function debug() {
  //     gsap.delayedCall(0.5, function() {
  //         parent.gotoSlideNumber(1);
  //         game.setTool('spray');
  //     })
  // }

  // debug();
});

// swipeBtnNext.addEventListener('click', function() {
//     if (!parent.isActivate) return;
//     parent.instance().slideNext();
// });

/**
 * @param "arr" (required) - array-like or iterable object to convert it to an array.
 * @param "callbackFn" (optional) - function to call on every element of the array.
 * @param "thisArg" (optional) - value to use as this when executing callback
 * Return value - new Array instance
 *
 * The callbackFn argument usage is like in Array.map() callback.
 * The callbackFn function accepts the following arguments:
 *      @param "currentValue" (required) - the current element being processed in the array.
 *      @param "index" (optional) - the index of the current element being processed in the array.
 *      @param "array" (optional) - he array map was called upon.
 * Callback function that is called for every element of "arr". Each time callback executes, the returned value is added to new array ("arNew").
 */
function arrayFrom(arr, callbackFn, thisArg) {
  //if you need you can uncomment the following line
  //if(!arr || typeof arr == 'function')throw new Error('This function requires an array-like object - not null, undefined or a function');

  var arNew = [],
    k = [], // used for convert Set to an Array
    i = 0;

  //if you do not need a Set object support then
  //you can comment or delete the following if statement
  if (window.Set && arr instanceof Set) {
    //we use forEach from Set object
    arr.forEach(function (v) {
      k.push(v);
    });
    arr = k;
  }

  for (; i < arr.length; i++)
    arNew[i] = callbackFn ? callbackFn.call(thisArg, arr[i], i, arr) : arr[i];

  return arNew;
}

//You could also use it without the following line, but it is not recommended because native function is faster.
Array.from = Array.from || arrayFrom; //We set it as polyfill
