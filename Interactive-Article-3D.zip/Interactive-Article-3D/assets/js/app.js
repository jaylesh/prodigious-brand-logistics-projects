// resized , http://www.fabiobiondi.com/blog/2012/08/createjs-and-html5-canvas-resize-fullscreen-and-liquid-layouts/
(function (w, $) {
    var textCarousel,
        noOfTextCarousel = 4,
        scenceId = 0,
        mc, // Hammer js instance
        stage,
        canvas,
        queue,
        sequenceName = "assets/img/gold-images/MLB.GOLD.Toolbox_Pack_",
        images = [],
        bmp,
        handOpen,
        handPinch,
        handMoveUp,
        handMoveDown,
        floatingIcon,
        m,
        rotate360Interval,
        frameRate = 30,
        size = {w: 600, h: 600},
        currentFrame = 0,
        totalFrames = 143,
        scenes = [
            [{
                scene: 0,
                label: 'fixed',
                images: {start: 0, end: 0},
                play: true
            }],
            [{
                scene: 1,
                label: 'rotate',
                images: {start: 1, end: 26},
                play: false,
            }],
            [{
                scene: 2,
                label: 'half open',
                images: {start: 27, end: 51},
                play: false,
            }],
            [{
                scene: 3,
                label: 'open box',
                images: {start: 52, end: 88},
                play: false,
            }],
            [{
                scene: 4,
                label: 'move stick up',
                images: {start: 91, end: 105},
                play: false,
            }],
            [{
                scene: 5,
                label: 'close box',
                images: {start: 106, end: 142},
                play: false,
            }],
        ];


    function init() {

        var d = document,
            e = d.documentElement,
            g = d.getElementsByTagName('body')[0],
            container,
            goldBtn,
            scaleAxisDefault = 1,
            scaleAxisMobile = 0.7,
            canvas3dDiv;

            canvas = document.getElementById("stage");
        if (!canvas || !canvas.getContext) return;

        // Init hammer js touch event
        mc = new Hammer.Manager(canvas, { recognizers: [[Hammer.Tap]]});

        goldBtn = $('.btn_gold');
        m = $('.container');

        canvas3dDiv = $('.canvas-3d');
        textCarousel = $('.carousel-container');
        floatingIcon = $('.icon-floating');

        stage = new createjs.Stage(canvas);
        stage.enableMouseOver(true);
        stage.mouseMoveOutside = true;
        createjs.Touch.enable(stage);
        container = new createjs.Container();

        stage.addChild(container);

        // Load hands picto on canvas
        handOpen = new createjs.Bitmap();
        handOpen.image = getImage('hand-open');
        container.addChild(handOpen);

        handPinch = new createjs.Bitmap();
        handPinch.image = getImage('hand-pinch');
        container.addChild(handPinch);

        handMoveUp = new createjs.Bitmap();
        handMoveUp.image = getImage('hand-up');
        container.addChild(handMoveUp);

        handMoveDown = new createjs.Bitmap();
        handMoveDown.image = getImage('hand-down');
        container.addChild(handMoveDown);

        handOpen.alpha = handMoveUp.alpha = handPinch.alpha = handMoveDown.alpha = 0;

        function handleTick() {
            stage.update();
        }

        // TICKER
        createjs.Ticker.addEventListener("tick", handleTick);
        createjs.Ticker.useRAF = true;

        bmp = new createjs.Bitmap();
        bmp.image = images[0].image;//queue.getResult("1");
        container.addChildAt(bmp,0);

        onResize();

        playScene(0);

        animate();

        function getImage(id){
            return queue.getResult(id);
        }

        // Image resize and center image in canvas
        function onResize(evt) {
            var w = !isMobile.any ? window.innerWidth / 2 : canvas3dDiv.innerWidth();
            var h = canvas3dDiv.innerHeight();

            stage.canvas.width = w;
            stage.canvas.height = h;

            // Image resize and center image in canvas
            if (w > 415) {
                bmp.scaleX = bmp.scaleY = handOpen.scaleX = handOpen.scaleY
                    = handPinch.scaleX = handPinch.scaleY = handMoveUp.scaleX
                    = handMoveUp.scaleY = handMoveDown.scaleX = handMoveDown.scaleY
                    = scaleAxisDefault;

                bmp.x = (stage.canvas.width - bmp.image.width * bmp.scaleX) / 2;
                bmp.y = (stage.canvas.height - bmp.image.height * bmp.scaleY) + 132;

                handOpen.x = bmp.x + 340;
                handOpen.y = bmp.y + 200;

                handPinch.x = bmp.x + 320;
                handPinch.y = bmp.y + 130;

                handMoveUp.x = bmp.x + 355;
                handMoveUp.y = bmp.y + 330;

                handMoveDown.x = bmp.x + 355;
                handMoveDown.y = bmp.y + 150;

            } else {
                bmp.scaleX = bmp.scaleY = scaleAxisMobile;
                bmp.x = (stage.canvas.width - bmp.image.width * bmp.scaleX) / 2;
                bmp.y = (stage.canvas.height - bmp.image.height * bmp.scaleY) + 110;

                handOpen.scaleX = handOpen.scaleY = scaleAxisMobile;
                handOpen.x = bmp.x + 235;
                handOpen.y = bmp.y + 140;

                handPinch.scaleX = handPinch.scaleY = scaleAxisMobile;
                handPinch.x = bmp.x + 220;
                handPinch.y = bmp.y + 90;

                handMoveUp.scaleX = handMoveUp.scaleY = scaleAxisMobile;
                handMoveUp.x = bmp.x + 250;
                handMoveUp.y = bmp.y + 220;

                handMoveDown.scaleX = handMoveDown.scaleY = scaleAxisMobile;
                handMoveDown.x = bmp.x + 250;
                handMoveDown.y = bmp.y + 100;

               
            }

            stage.update();
        }

        // onResize();
        window.addEventListener('resize', onResize, false);
        window.addEventListener('orientationchange', onResize, false);

        //gold button
        goldBtn.on('click touch', function(){
            classGetter(m ,'step-2', /step+/gm);
        });
    }

    // Show/Hide hand image on cigaret pack
    function toggleBmpHandPicto(bmpHandPicto) {
        if (!bmpHandPicto.alpha) {
            createjs.Tween.get(bmpHandPicto).to({alpha:1}, 500);
        } else {
            createjs.Tween.get(bmpHandPicto).to({alpha:0}, 300);
        }
        stage.update();
    }

    //logic class tester
    function classGetter(element, className, expression) {
        var o = element.hasClassRegEx(expression);
        if (o.found) {
            element.removeClass(o.className);
            if(element != null) { element.addClass(className) };
        }
    }

    // play scene
    function playScene(scene, complete) {
        scenceId = scene;
        bmpHandPictoEvent(scene);
        var o = getSceneInfo(scene);
        if (o.scene == null) {
            return
        }
        currentFrame = o.images.start;
        var total = scene == 5 ? o.images.end - 1 : o.images.end;
        rotate360Interval = setInterval(function () {
            if (currentFrame == total) {
                clearInterval(rotate360Interval);
                if (typeof complete === "function") {
                    complete();
                }
            }
            update360(1)
        }, frameRate)
    }

    function update360(frames) {
        currentFrame += frames;
        bmp.image = images[currentFrame].image;
    }

    // find scene info
    function getSceneInfo(id) {
        var k = {};
        _.each(scenes, function (o, i) {
            _.each(o, function (s) {
                if (s.scene == id) {

                    return k = s;
                }
            })
        })
        return k
    }

    //add floating info
    function floatingInfo(sceneId){
        switch (sceneId) {
            case 1:  return floatingIcon.addClass('active-'+ sceneId);
            case 2: return classGetter(floatingIcon, 'active-2',/active+/gm);
            case 3 : return classGetter(floatingIcon, null, /active+/gm);
            default: return;
        }
    }

    // preloader
    function loadImage() {
        queue = new createjs.LoadQueue();
        queue.on('fileload', handleFileLoad, this);
        queue.on("complete", handleComplete, this);
        queue.on('progress', handleProgress, this);
        queue.on('error', handleError, this);
        for (let i = 0; i < totalFrames; i++) {
            queue.loadFile({id: i, src: sequenceName + i + ".png"});
        }
        queue.loadFile({id:'hand-open', src:'assets/img/hand-move-white.png'});
        queue.loadFile({id:'hand-pinch', src:'assets/img/hand-rotate-white.png'});
        queue.loadFile({id:'hand-up', src:'assets/img/hand-move-black.png'});
        queue.loadFile({id:'hand-down', src:'assets/img/hand-move-down-black.png'});

        queue.load();
    }
    function handleError(error) {
        //console.log('error')
    }
    function handleProgress(evt) {
        loader(Math.round(evt.progress * 100))
    }
    function handleFileLoad(evt) {
        var item = evt.item; // A reference to the item that was passed in to the LoadQueue
        images.push({id: "image" + item.id, image: evt.result});
    }
    function handleComplete(evt) {
        $('.loading-page').animate({ opacity: 0 }, 500, function() {
            $(this).remove();
            init();
        });
    }
    function loader(percentage) {
        $(".loading-page .pre-loader h1").html(percentage + "%");
        $(".loading-page .pre-loader hr").css("width", percentage + "%");
    }
    w.preload = loadImage;

    // Pack and Text Animation Section
    function animate () {
        if (isMobile.any) {
            mobileTouchEvent();
        } else { // Desktop click event only
            desktopPackAnimation();
        }
    }

    function desktopPackAnimation() {
        var nextSceneId = scenceId + 1;
        $(canvas).on('click', function() {
            $(this).off('click'); // Remove click event on elem
            if ( nextSceneId < scenes.length ) {
                playScene(nextSceneId, onComplete);
            }
        });
    }

    function mobileTouchEvent() {
        mc.on('tap swipe pinch', function(ev) {
            mc.remove(ev.type); // Remove listener when event is triggered
            switch (ev.type) {
                case "tap":
                    onTap(ev);
                    break;
                case "swipe":
                    onSwipe(ev);
                    break;
                case "pinch":
                    onPinch(ev);
                    break;
            }
        });
    }

    function onTap(ev) {
        playScene(scenceId + 1, onComplete);
    }

    function onSwipe(ev) {
        var direction = ev.direction;
        if (direction === Hammer.DIRECTION_UP || direction === Hammer.DIRECTION_DOWN) {
            playScene(scenceId + 1, onComplete);
        }
    }

    function onPinch(ev) {
        playScene(scenceId + 1, onComplete);
    }

    // playScene() callback function
    function onComplete() {

        if (isMobile.any) {
            switch(scenceId) {
                case 1:
                    mc.add(new Hammer.Swipe({direction: Hammer.DIRECTION_UP}));
                    break;
                case 2:
                    mc.add(new Hammer.Pinch({enable: true}));
                    break;
                case 3:
                    mc.add(new Hammer.Swipe({direction: Hammer.DIRECTION_UP}));
                    break;
                case 4:
                    mc.add(new Hammer.Swipe({direction: Hammer.DIRECTION_DOWN}));
                    break;
                case 5:
                    classGetter(m,'step-3', /step+/gm);
                    break;
            }
        } else {
            $(canvas).on('click', desktopPackAnimation);
            if (scenceId === 5) {
                classGetter(m,'step-3', /step+/gm);
            }
        }

        floatingInfo(scenceId);
        textSlideUp();
    }

    function bmpHandPictoEvent(scenceId) {
        switch (scenceId) {
            case 1:
                toggleBmpHandPicto(handOpen);
                break;
            case 2:
                toggleBmpHandPicto(handOpen);
                toggleBmpHandPicto(handPinch);
                break;
            case 3:
                toggleBmpHandPicto(handPinch);
                toggleBmpHandPicto(handMoveUp);
                break;
            case 4:
                toggleBmpHandPicto(handMoveUp);
                toggleBmpHandPicto(handMoveDown);
                break;
            case 5:
                toggleBmpHandPicto(handMoveDown);
                break;
        }
    }

    function textSlideUp() {
        var slideClass = 'info-' + scenceId;
        // Stop execution if total text carousel
        if (scenceId === noOfTextCarousel) return;
        if ($(textCarousel).hasClass(slideClass)) {
            $(textCarousel).removeClass(slideClass);
            $(textCarousel).addClass('info-' + (scenceId + 1));
        }
    }

})(window, jQuery);

/* Class remmover */
(function ($) {
    $.fn.hasClassRegEx = function (regex) {
        var classes = $(this).attr('class');

        if (!classes || !regex) { return false; }

        classes = classes.split(' ');
        var len = classes.length;

        for (var i = 0; i < len; i++) {
            if (classes[i].match(regex)) { return { found: true, className: classes[i] } }
        }

        return { found: false, className: null };
    };
})(jQuery);


window.addEventListener('load', preload, false);

// TODO: Do not forger to add bitmap show/hide for moblie
