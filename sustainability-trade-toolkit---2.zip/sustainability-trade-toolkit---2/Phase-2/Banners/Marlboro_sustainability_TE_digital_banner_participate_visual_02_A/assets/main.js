window.onload = function(){






var tl = new TimelineMax();
mySplitText = new SplitText(".banner-3 #text_1", {type:"chars"});


tl.to(".banner-3 #text_1", 0, {  opacity:1});
tl.staggerFrom(mySplitText.chars, 0.5, {opacity:0,  ease: SteppedEase.config(1)}, 0.037, "+=0");
tl.to(".banner-3 #text_2-anim", 0.5, { ease: Power1.easeOut, opacity:1, height:30});
tl.to(".banner-3 #cta", 0.5, { ease: Power1.easeOut, scale:1});
tl.to(".banner-3 #cig1", 0.8, { ease: Power1.easeOut, scale:1, y:-95, x: 41});
tl.to(".banner-3 #cig2", 0.8, { ease: Power1.easeOut, scale:1, y:-81, x: -30}, "-=0.5");


}



