window.onload = function(){




    // function cig(){
    //     var cig = new TimelineMax();
 
    //     cig.to((".banner-2 #cig1"), 0.5, {ease: Power0.easeOut,opacity:1});
    //     cig.to((".banner-2 #cig2"), 0.5, {ease: Power0.easeOut,opacity:1});
    //     cig.to((".banner-2 #cig3"), 0.3, {ease: Power0.easeOut,opacity:1});
    //     cig.to((".banner-2 #cig4"), 0.3, {ease: Power0.easeOut,opacity:1});
    //     cig.to((".banner-2 #cig5"), 0.3, {ease: Power0.easeOut,opacity:1});
    //     cig.to((".banner-2 #cig6"), 0.3, {ease: Power0.easeOut,opacity:1});
    //     return cig;
    // }	

var tl = new TimelineMax();
mySplitText = new SplitText(".banner-2 #text_1", {type:"chars"});

tl.to(".banner-2 #text_1", 0, {  opacity:1});
tl.staggerFrom(mySplitText.chars, 0.5, {opacity:0,  ease: SteppedEase.config(1)}, 0.037, "+=0");
tl.to(".banner-2 #cta", 0.5, { ease: Power1.easeOut, right:0});
tl.to([".banner-2 #background", ".banner-2 #text_1", ".banner-2 #cigdiv"], 0.5, { ease: Power1.easeOut, left:-115}, "-=0.5");
tl.to(".banner-2 #pack", 0.5, { ease: Power1.easeOut, top:0});
tl.to(".banner-2 #cta", 0.5, { ease: Power1.easeOut, css:{color:"rgba(255, 255, 255, 1)"}});
tl.to(".banner-2 #cigdiv", 0.5, { ease: Power1.easeOut, opacity:0}, "-=0.5");



}



