
$( document ).ready(function() {
    // console.log("READY")

    var myElement = document.getElementsByClassName('myImg2');
    var hammertime = new Hammer(myElement[0]);
    var isMobile = false;
    var panHorizontal = 0, panVertical = 0, panOpen = 0;
    var maxHorizontal = 17;
    var minHorizontal = 0;
    var maxVertical = 8;
    var minVertical = 0;
    var imgPath = "assets/img/";

    var timeOutOnClick = 0;
    var timeOutOnPlayReverse = 0;
    var timeOutOpen = 0;
    var open_img = 9;
    var timer = 5000;
    var executed = false;

    var imageArr = [];

    for(var i=0; i<= maxVertical; i++){
        for(var j=0; j<= maxHorizontal; j++){
            imageArr.push(imgPath +i+"/MARLBORO_PACK_"+j +'.png');
        }
    }


    for(var k=0; k<= open_img; k++){
        imageArr.push(imgPath+ "open_img/Sustainability_"+k +'.png');
    }


    $("#up, #down, #left, #right").on( "mousedown touchstart",clickAndHoldHandler);
    $("#up, #down, #left, #right").on( "mouseup touchend",releaseHandler);

    hammertime.get('swipe').set({ direction: Hammer.DIRECTION_ALL});
    hammertime.on("swipeup", onSwipeUp);

    var Progress = {
        bar : null,
        index : 0,
        imgList : [],
        init: function(){
            var box = document.getElementById("progressBox");
            var prog = document.createElement("progress");
            box.appendChild(prog);
            // console.log('-',prog)
            this.bar = prog;
        },

        loadImages: function(paths) {
            var self = this,
                i, length = paths.length;
            // this.bar.max = length;
            for (i=0;i<length;i++){
                var img = new Image();
                img.onload = function() {
                    self.increase();
                    if (self.index >= length){
                        self.done();
                    }
                };
                img.src = paths[i];
                this.imgList.push(img);

            }
        },

        increase: function(){
            this.index++;
            // this.bar.value = this.index;
            var preloaderNUmb = parseInt((100/imageArr.length)*this.index);
            $('.num').text(preloaderNUmb + '%');
            $(".loading-page hr").css("width", preloaderNUmb + "%");
            if(preloaderNUmb === 100){
                $('.loading-page').hide()
            }
        },

        done : function() {
            // console.log("I am done loading");
            /* this.bar.style.display = "none";
             var showBox = document.getElementById("show");
             for (var i =0, l = this.index;i<l;i++) {
                 showBox.appendChild(this.imgList[i]);
             }*/
        }

    };

    Progress.loadImages(imageArr);


    function clickAndHoldHandler(e){
        // console.log(e.currentTarget.id);
        clearInterval(timeOutOnClick);
        timeOutOnClick = setInterval(function(){
        switch(e.currentTarget.id){

            case "right":
                panHorizontal++;
                break;

            case "left":
                panHorizontal--;
                break;

            case "up":
                panVertical--;
                break;

            case "down":panVertical++;
                break;

            case "panend":

                break;
        }

        //hide show arrows
        if(panHorizontal > minHorizontal){
            $('.btn-left').css('opacity',1);
        }else if(panHorizontal === minHorizontal){
            $('.btn-left').css('opacity',0.2);
        }


        if(panHorizontal < maxHorizontal){
            $('.btn-right').css('opacity',1);
        }else if(panHorizontal === maxHorizontal){
            $('.btn-right').css('opacity',0.2);
        }


        if(panVertical > minVertical){
            $('.btn-up').css('opacity',1);
        }else if(panVertical === minVertical){
            $('.btn-up').css('opacity',0.2);
        }


        if(panVertical < maxVertical){
            $('.btn-down').css('opacity',1);
        }else if(panVertical === maxVertical){
            $('.btn-down').css('opacity',0.2);
        }

            changeImage();

        }, 100);




    }

    function releaseHandler(e){
        // console.log(e.currentTarget.id);
        clearInterval(timeOutOnClick);


    }
//
//     function playReverse(){
//         timeOutOnPlayReverse = setInterval(function(){
//             panVertical--
//             panHorizontal--
//             changeImage();
// // console.log(panVertical,panHorizontal)
//              if(panVertical == 0 && panHorizontal == 0)clearInterval(timeOutOnPlayReverse);
//         },100);
//     }

    function changeImage(){
        if(panHorizontal > maxHorizontal)panHorizontal = maxHorizontal;
        if(panHorizontal < minHorizontal)panHorizontal = minHorizontal;

        if(panVertical > maxVertical)panVertical = maxVertical;
        if(panVertical < minVertical)panVertical = minVertical;

        $(".myImg").attr('src',imgPath+panVertical+"/MARLBORO_PACK_"+panHorizontal+".png")

        // console.log(panHorizontal,panVertical)

    }

    function openBox() {
        $(".myImg2").attr('src',imgPath+"open_img/Sustainability_"+panOpen+".png")
    }

    function nextpage(){
        var main = $('.container');
        setTimeout(function(){
            main.removeClass('screen-3');
            main.addClass('screen-4');

            }, timer);
    }
    function onSwipeUp(){
        if (!executed) {
            executed = true;
            timeOutOpen = setInterval(function () {
                panOpen++;
                if (panOpen === 9) clearInterval(timeOutOpen, nextpage());
                openBox();
            }, 100);
        }

    }

    //click arrow
    $('.arrow-swipe').click(function () {
        $('.container').addClass('screen-3');
    });




});
