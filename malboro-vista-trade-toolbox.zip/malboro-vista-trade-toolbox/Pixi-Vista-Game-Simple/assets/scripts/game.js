"use strict";
(function(w) {
    function Game(width, height) {
        var _s = this;

        _s.loader = PIXI.Loader.shared;
        _s.render, _s.resizeTimer, _s.addTimerId;
        _s.app, _s.stage, _s.container, _s.gameWidth = width, _s.gameHeight = height;
        _s.lists = [], _s.balls = [];
        _s.clips = ["blue", "dark-violet", "green", "orange"]; //, "sunset-1", "sunset-2"
        _s.speed = 1.5, _s.shuffleCount = 0, _s.circleToAddCounter = 0, _s.maxCircleToAdd = 12;
        _s.ballsContainer, _s.bcWidth = 90, _s.bcHeight = 120;
        _s.themes = ["forest mist", "exotic zest", "garden zing", "summer splash"];
        _s.box, _s.target, _s.currentTarget, _s.currentHitObject, _s.isDragging, _s.isPointerMoving, _s.data;
        _s.isOver = false, _s.isShowingOutro = false;
        _s.htmlGameLevelElement, _s.htmlTimeElement, _s.outroElement, _s.swirlLinesElement, _s.nextLevelBtnElement; //html
        _s.gScore = _s.wScore = 0, _s.level = 1; //game scores
        _s.timer = window.timer, _s.timeMax = 30;
        _s.gameHitInfo = { good: "WELL DONE!", bad: "OOOPS!\nTRY AGAIN." }

        // methods
        _s.init = function() {
            _s.preload();
        };
        _s.preload = function() {
            _s.loader.add("blue", "./assets/img/blue.png");
            _s.loader.add("dark-violet", "./assets/img/dark-violet.png");
            _s.loader.add("green", "./assets/img/green.png");
            _s.loader.add("orange", "./assets/img/orange.png");
            _s.loader.add("sunset-1", "./assets/img/orange-sunset-1.png");
            _s.loader.add("sunset-2", "./assets/img/orange-sunset-2.png");
            _s.loader.add("target", "./assets/img/target.png");
            _s.loader.add("orange-ball", "./assets/img/orange-ball.png");
            _s.loader.add("blue-ball", "./assets/img/blue-ball.png");
            _s.loader.add("dark-violet-ball", "./assets/img/dark-violet-ball.png");
            _s.loader.add("green-ball", "./assets/img/green-ball.png");
            // _s.loader.add("sunset-1-ball", "./assets/img/sunset-1-ball.png");
            //_s.loader.add("sunset-2-ball", "./assets/img/sunset-2-ball.png");
            _s.loader.load();
            _s.loader.onComplete.add(function() {
                var play = $(".btn-play");
                _s.htmlTimeElement = $("#header");
                _s.htmlGameLevelElement = $(".level-game");
                _s.outroElement = $(".outro");
                _s.swirlLinesElement = $(".swirl.el");
                _s.nextLevelBtnElement = $(".btn-next-level");

                gsap.fromTo(play, 1, { alpha: 0 }, {
                    alpha: 1,
                    onComplete: function() {
                        play.on('click', function() {
                            var intro = $(".intro");
                            play.off('click');
                            var sh =
                                (_s.gameHeight - _s.swirlLinesElement.height()) / 2 - 70;
                            gsap.to(_s.swirlLinesElement, 0.5, {
                                y: -sh
                            });
                            gsap.to(intro, 0.5, {
                                alpha: 0,
                                onComplete: function() {
                                    intro.hide();
                                    _s.startGame();
                                }
                            });
                            var timeH = $(".time").outerHeight();
                            gsap.set(_s.htmlGameLevelElement, { display: "block", alpha: 0 });
                            gsap.to(_s.htmlGameLevelElement, 0.5, { autoAlpha: 1 });
                            gsap.to(_s.htmlTimeElement, 0.5, {
                                y: -(timeH + 37),
                                scale: 0.9
                            });
                        })
                    }
                });
            });
        };

        _s.startGame = function() {
            _s.buildScene();
            _s.addEvents();
            //_s.timer.start(_s.timeMax);
            _s.bump = new Bump(PIXI);
        };
        _s.buildScene = function() {
            PIXI.utils.skipHello();
            _s.app = new PIXI.Application({
                width: _s.gameWidth,
                height: _s.gameHeight,
                view: document.getElementById("game-stage"),
                transparent: true,
                resolution: window.devicePixelRatio || 1,
            });

            _s.container = new PIXI.Container();
            _s.container.position.set(0, Math.round(_s.header().height));
            _s.app.stage.addChild(_s.container);

            _s.ballsContainer = new PIXI.Container();
            _s.app.stage.addChild(_s.ballsContainer);

            _s.app.ticker.stop();
            gsap.ticker.add(_s.start);
            _s.app.ticker.add(_s.update);

            _s.target = new PIXI.Sprite(_s.loader.resources["target"].texture);
            _s.target.scale.set(0.35);
            _s.target.anchor.set(0.5);
            _s.target.x = _s.bcWidth / 2;
            _s.target.y = _s.target.height / 2;
            _s.ballsContainer.addChild(_s.target);

            //debug clips
            _s.graphic = new PIXI.Graphics();
            _s.graphic.alpha = 0.4;
            _s.graphic.beginFill(0xc34288);
            _s.graphic.drawRect(-(_s.bcWidth / 2), _s.target.height / 2, _s.bcWidth, _s.bcHeight);
            _s.graphic.endFill();
            //_s.container.addChildAt(_s.graphic, 0);
            //_s.ballsContainer.addChild(_s.graphic);

            gsap.fromTo(
                _s.target,
                1, { alpha: 0, scaleX: 0, scaleY: 0 }, {
                    alpha: 1,
                    scaleX: 0.35,
                    scaleY: 0.35,
                    ease: 'sine',
                    // y: _s.target.height / 2,
                    onComplete: function() {
                        _s.addBalls({ color: "orange-ball", hit: 3, name: "orange" });
                        _s.addBalls({ color: "blue-ball", hit: 0, name: "blue" });
                        //_s.addBalls({ color: "sunset-1-ball" });
                        _s.addBalls({ color: "green-ball", hit: 2, name: "green" });
                        //_s.addBalls({ color: "sunset-2-ball" });
                        _s.addBalls({ color: "dark-violet-ball", hit: 1, name: "dark-violet" });
                    },
                }
            );
            gsap.utils.shuffle(_s.clips);
            _s.nextLevel(1, 2);
        };
        _s.addWithDelay = function() {
            if (_s.isOver) return;
            var max = _s.clips.length - 1;
            var c = _s.shuffleCount;
            //_s.addTimerId = setTimeout(_s.addWithDelay, 5000);
            //if (_s.circleToAddCounter < _s.maxCircleToAdd) {
            var circle = _s.circle(_s.clips[c]);
            circle.isLast = true

            if ((circle.scale.x <= 0.35)) {
                _s.container.addChildAt(circle, 0);
            }
            if (circle.blur) {
                _s.container.addChildAt(circle, 0)
            } else {
                _s.container.addChild(circle);
            }
            circle.updateTransform();
            _s.circleToAddCounter = _s.circleToAddCounter + 1;
            _s.shuffleCount = _s.shuffleCount >= max ? (_s.shuffleCount = 0) : _s.shuffleCount + 1;
            //shuffle if has max count
            if (_s.shuffleCount >= max) {
                gsap.utils.shuffle(_s.clips);
            }
        };
        _s.circle = function(o) {
            const parent = _s.app.view.parentNode;
            let w = parent.clientWidth;
            let h = parent.clientHeight;

            var texture = _s.loader.resources[o].texture;
            var _sp = new PIXI.Sprite();
            _sp.anchor.set(0.5);
            var c = new PIXI.Sprite(texture);
            _sp.addChild(c);
            c.anchor.set(0.5);

            _sp.interactive = true;
            _sp.interactiveChildren = true;
            _sp.roundPixels = true;
            _sp.name = o;
            _sp.clip = c;
            var ran = gsap.utils.random(0.2, 0.7);
            var scale = ran;
            var yPos = gsap.utils.random(50, 170);

            c.scale.set(scale);
            _sp.x = Math.round(w + c.width);
            _sp.y = yPos;
            _sp.blur = false;
            _sp.data = texture;

            //filter
            const blurFilter1 = new PIXI.filters.BlurFilter();
            if (c.scale.x <= 0.3) {
                blurFilter1.blur = gsap.utils.random(3, 5);
                c.filters = [blurFilter1];
                _sp.blur = true;
                _sp.interactive = false;
            }

            if (!c.blur) {
                var fz = (Math.round(ran * 100) / 16) + 'em';
                var t = _s.addText(o, fz);
                t.anchor.set(0.45);
                t.position.set(0, 0);
                _sp.circular = true;
                _sp.text = t;
                t.alpha = 0;
                _sp.addChild(t);
            }
            _s.lists.push({
                mc: _sp,
                color: _sp,
                scale: c.scale,
                text: _s.getText(o),
                texture: texture,
            });

            return _sp;
        };
        _s.addBalls = function(o) {
            var container = new PIXI.Sprite();
            container.anchor.set(0.5);
            var ball = _s.ball(o);
            _s.ballsContainer.addChild(container);
            container.x = _s.bcWidth / 2;
            container.y = _s.target.height / 2;
            container.addChild(ball);
            _s.balls.push({ mc: ball });
            _s.alignBalls();
        };
        _s.alignBalls = function() {
            var th = _s.target.height;
            _s.balls.forEach((e, i) => {
                var ball = e.mc;
                _s.removeDragEvent(ball);
                if (i === 0) {
                    _s.addDragEvent(ball);
                    ball.info.origin = { x: 0, y: 0 };
                }
                gsap.fromTo(
                    ball,
                    0.4, {
                        x: 0,
                        y: i === 0 ? th : 150,
                        alpha: 1,
                    }, {
                        y: th * i,
                        delay: 0.5 * i,
                    }
                );
            });
        };
        _s.ball = function(o) {
            let b = new PIXI.Sprite(_s.loader.resources[o.color].texture);
            b.info = o;
            b.name = o.name;
            b.index = _s.balls.length;
            b.anchor.set(0.5);
            b.info.scale = 0.28;
            b.interactive = true;
            b.circular = true;
            b.buttonMode = true;
            //testing
            // const t = new PIXI.Text(o.hit, { fill: "#ffffff", fontFamily: "NeulandGrotesk-Condensed-Light" });
            // t.anchor.set(0.45);
            // t.position.set(0, 0);
            // t.scale.set(6);
            // b.addChild(t);
            b.scale.set(0.28);
            return b;
        };
        //texts
        _s.addText = function(o, fz) {
            const style = new PIXI.TextStyle({
                fontFamily: "NeulandGrotesk-Condensed-Light",
                fontSize: fz,
                //fontStyle: "normal",
                fontWeight: "lighter",
                align: "center",
                fill: "#ffffff",
                //lineHeight: 2,
                //leading: "2.2",
                wordWrap: true,
                padding: 8,
                //lineJoin: "round",
                // miterLimit: 12,
                trim: true,
                wordWrapWidth: 80,
                whiteSpace: '<br/>',
            });
            var t = _s.getText(o);
            const text = new PIXI.Text(t.theme, style);
            text.info = t;
            return text;
        }
        _s.getText = function(o) {
            switch (o) {
                case 'blue':
                    return {
                        theme: _s.themes[0],
                        color: "blue",
                        texture: _s.loader.resources["blue-ball"].texture,
                        hit: 0,
                    };
                case 'dark-violet':
                    return {
                        theme: _s.themes[1],
                        color: "dark-violet",
                        texture: _s.loader.resources["dark-violet-ball"].texture,
                        hit: 1,
                    };
                case 'green':
                    return {
                        theme: _s.themes[2],
                        color: "green",
                        texture: _s.loader.resources["green-ball"].texture,
                        hit: 2,
                    };
                case 'orange':
                    return {
                        theme: _s.themes[3],
                        color: "orange",
                        texture: _s.loader.resources["orange-ball"].texture,
                        hit: 3,
                    };
            }
        }

        _s.hitText = function(o) {
            const style = new PIXI.TextStyle({
                fontFamily: "NeulandGrotesk-Condensed-Regular",
                fontSize: o.fz,
                //fontStyle: "normal",
                fontWeight: "Bold",
                align: "center",
                fill: "#ffffff",
                //lineHeight: "2",
                // leading: "1.5",
                wordWrap: true,
                wordWrapWidth: 170,
                whiteSpace: "<br/>",
            });
            const text = new PIXI.Text(o.text, style);
            return text;
        }

        _s.updateScore = function(score, isWrong) {
            if (isWrong) {
                _s.wScore = _s.wScore + score;
                _s.htmlGameLevelElement.find(".wrong").html("wrong: " + _s.wScore);
            } else {
                _s.gScore = _s.gScore + score;
                _s.htmlGameLevelElement.find(".matching").html("matches: " + _s.gScore);
            }
            _s.checkedScore();
        }
        _s.updateLevel = function(level) {
            _s.htmlGameLevelElement.find(".levels").html('Level ' + level);
        }
        _s.checkedScore = function() {
            if (_s.wScore >= 10) {
                _s.isOver = true;
            } else if (_s.gScore >= 10) {
                _s.isOver = true;
            }
        };
        _s.showOutroPanel = function() {

            var welldoneMsg = "<br><br> well done.";
            var tryAgainMsg = "<br><br> try again.";
            var tryAgain = _s.wScore >= 5 ? true : false;
            var nextLevelBtnTxt = tryAgain ? "Replay" : "Next Level";
            var tempMessage = "you got<br> $1 out 0f 10<br> destinations";
            _s.outroElement.find(".message").html(tempMessage);

            if (_s.level === 2) {
                nextLevelBtnTxt = "Replay"
            }

            var message = _s.outroElement.find(".message").html().split("$1").join(_s.gScore);
            _s.outroElement.find(".message").html(message + (tryAgain ? tryAgainMsg : welldoneMsg));
            _s.nextLevelBtnElement.html(nextLevelBtnTxt);

            gsap.set(_s.outroElement, { display: "flex", alpha: 0 });
            gsap.to(_s.outroElement, 0.5, { autoAlpha: 1 });

            _s.nextLevelBtnElement.on("click", function() {

                if (_s.level == 2) {
                    _s.nextLevel(1, 1.5);
                } else if (tryAgain) {
                    //restart game
                    _s.nextLevel(1, 1.5);
                    //console.log('replay');
                } else {
                    //level 2
                    _s.nextLevel(2, 3);
                    //console.log("next");
                }
            });
        }

        _s.hideOutroPanel = function() {
                gsap.to(_s.outroElement, 0.5, {
                    autoAlpha: 0,
                    onComplete: function() {
                        gsap.set(_s.outroElement, { display: "none" });
                    }
                });
            }
            //events
        _s.onResized = function() {
            const parent = _s.app.view.parentNode;
            const canvas = _s.app.view;
            let w = parent.clientWidth;
            let h = parent.clientHeight;
            _s.gameWidth = w;
            _s.gameHeight = h;
            canvas.style.width = w + "px";
            canvas.style.height = h + "px";
            canvas.width = w;
            canvas.height = h;
            _s.app.renderer.resize(w, h);
            _s.container.position.set(0, _s.header().height);
            _s.ballsContainer.position.set((w - _s.ballsContainer.width) / 2, h - _s.bcHeight - 5);
        };

        _s.update = function(delta) {
            if (_s.isOver) {
                _s.stop();
                return;
            }
            if (_s.lists.length > 0) {
                var last = _s.lists[_s.lists.length - 1].mc;
                if (last.x < (_s.gameWidth - (last.clip.width / 2)) && last.isLast) {
                    last.isLast = false;
                    //console.log("add", last.x);
                    _s.addWithDelay();
                }
                _s.lists.forEach((e, i) => {
                    var sprite = e.mc;
                    if (e !== null) {
                        if (sprite == null) return;
                        var parent = sprite.parent;

                        //detect collison 
                        if (_s.isDragging && !sprite.isBlur) {
                            var current = _s.currentTarget;
                            // var collision = _s.bump.hit(current, sprite, false, true, true)
                            // if (collision) {
                            //     _s.currentHitObject = sprite;
                            //     sprite.isHit = true;
                            //     current.isHit = true;
                            // }
                            var collision = _s.bump.hitTestCircle(current, sprite, true, true, true);
                            if (collision && !sprite.isHit) {
                                _s.currentHitObject = sprite;
                                sprite.isHit = true;
                                current.isHit = true;
                            }
                        }

                        if (sprite.blur) {
                            sprite.x -= (_s.speed / 1.5) * delta;
                        } else {
                            sprite.x -= _s.speed * delta;
                        }
                        if (sprite.x < -sprite.clip.width) {
                            if (parent != null) {
                                if ((!sprite, blur && sprite.isHit)) {
                                    sprite.isHit = false;
                                    if (sprite.text) {
                                        sprite.clip.texture = e.texture;
                                        sprite.text.alpha = 0;
                                    }
                                }
                                _s.container.removeChild(sprite);
                                sprite.destroy({ children: true, baseTexture: true });
                                sprite = null;
                                _s.lists.splice(i, 1);
                            }
                        }
                    }
                });
            }
        };
        //-end update
        _s.start = function() {
            _s.app.ticker.update();
        }
        _s.rePlay = function() {
            _s.restart();
        };
        _s.nextLevel = function(level, speed) {
            _s.level = level;
            _s.updateLevel(_s.level);
            _s.speed = speed
            _s.restart();
        }
        _s.reset = function() {};
        _s.stop = function() {
            if (!_s.isShowingOutro) {
                _s.isShowingOutro = true;
                _s.balls.forEach((e, i) => {
                    var ball = e.mc;
                    _s.removeDragEvent(ball);
                });
                gsap.to(_s.container, 0.5, {
                    alpha: 0,
                    onComplete: function() {
                        _s.clearSprite();
                        _s.isEndDelay = gsap.delayedCall(0.85, function() {
                            if (_s.isEndDelay) {
                                _s.isEndDelay.kill();
                            }
                            _s.app.ticker.stop();
                            gsap.ticker.sleep() //remove(_s.start);
                            _s.showOutroPanel();
                        });
                    },
                });
                clearTimeout(_s.addTimerId);
            }
        };
        _s.restart = function() {
            _s.hideOutroPanel();
            _s.isOver = false;
            _s.isShowingOutro = false;

            _s.app.ticker.stop();
            gsap.utils.shuffle(_s.clips);
            _s.addWithDelay();
            _s.app.ticker.start();


            _s.gScore = _s.wScore = 0;
            _s.htmlGameLevelElement.find(".wrong").html("wrong: " + _s.wScore);
            _s.htmlGameLevelElement.find(".matching").html("matches: " + _s.gScore);
            gsap.to(_s.container, 0.8, {
                alpha: 1,
                onComplete: function() {
                    gsap.ticker.wake();
                }
            });
        };

        //removed clip from stage
        _s.clearSprite = function() {
            _s.container.removeChildren();
            _s.lists = [];
        };
        //swap position
        _s.swapPosition = function(arr) {
            var c = arr.shift();
            arr.push(c);
            gsap.delayedCall(0.15, _s.alignBalls, null);
        };

        //events
        _s.onDragStart = function(e) {
            var mc = e.currentTarget;
            _s.currentTarget = mc;
            _s.data = e.data;
            gsap.to(mc, 0.35, {
                scaleX: 0.32,
                scaleY: 0.32,
            });
            _s.isDragging = true;
        };
        _s.onDragMove = function(e) {
            if (_s.isDragging) {
                const newPosition = _s.data.getLocalPosition(this.parent);
                this.x = newPosition.x;
                this.y = newPosition.y;
                this.updateTransform();
            }
        };
        _s.onDragEnd = function(e) {
            var target = e.currentTarget;
            _s.isDragging = false;
            _s.currentTarget = null;
            _s.data = null;
            if (_s.currentHitObject != null && !_s.currentHitObject.blur) {
                target.isHit = true;
                _s.currentHitObject.isHit = true;
                var sprite = _s.currentHitObject;
                var text = sprite.text;
                var bInfo = target.name; //target.info.hit;
                var cInfo = sprite.name; //clip.text.info.hit;
                //console.log("ball -> ", bInfo, "  hit->", cInfo);

                var bul = "";
                if (bInfo === cInfo) {
                    bul = _s.gameHitInfo.good;
                    _s.updateScore(1);
                } else {
                    bul = _s.gameHitInfo.bad;
                    _s.updateScore(1, true);
                }
                gsap.to(text, 0.5, { alpha: 1 });
                sprite.clip.texture = text.info.texture;
                var scale = sprite.clip.scale.x;
                var fromYPos = scale <= 0.4 ? (sprite.clip.height - 10) : (sprite.clip.height - 30);
                var toYPos = scale <= 0.4 ? ((sprite.clip.height / 2) + 20) : ((sprite.clip.height / 2) + 15);
                scale = scale <= 0.4 ? 0.6 * 40 : (sprite.clip.scale.x * 40);
                var txt = _s.hitText({ text: bul, fz: scale });
                txt.anchor.set(0.5);
                sprite.addChild(txt);
                if (!txt) return;
                gsap.fromTo(txt, 1, { y: fromYPos, alpha: 0 }, {
                    y: (toYPos + 8),
                    alpha: 1,
                    onComplete: function() {
                        gsap.to(txt, 0.7, {
                            alpha: 0,
                            delay: 0.3,
                            onComplete: function() {
                                if (txt.parent != null) {
                                    //txt.parent.removeChild(txt);
                                    //stxt.destroy({ children: true, baseTexture: true });
                                    //txt = null;
                                }
                            }
                        });
                    }
                });
                _s.currentHitObject = null;
            }

            if (!target.isHit) {
                gsap.to(target, 0.35, {
                    x: target.info.origin.x,
                    y: target.info.origin.y,
                    scaleX: target.info.scale,
                    scaleY: target.info.scale,
                    ease: "sine",
                });
            } else if (target.isHit) {
                target.isHit = false;
                gsap.to(target, 0.5, {
                    scaleX: target.info.scale,
                    scaleY: target.info.scale,
                    alpha: 0,
                    ease: "sine",
                    onComplete: function() {},
                });
                if (_s.delayedCall) {
                    _s.delayedCall.kill();
                }
                _s.delayedCall = gsap.delayedCall(0.15, function() {
                    _s.removeDragEvent(target);
                    _s.swapPosition(_s.balls);
                });
            }
        };
        _s.addDragEvent = function(ball) {
            ball.on("pointerdown", _s.onDragStart)
                .on("pointerup", _s.onDragEnd)
                .on("pointerupoutside", _s.onDragEnd)
                .on("pointermove", _s.onDragMove);
        };
        _s.removeDragEvent = function(ball) {
            ball.off("pointerdown")
                .off("pointerup")
                .off("pointerupoutside")
                .off("pointermove");
        };
        //stage events
        _s.addEvents = function() {
            _s.onResized();
            window.addEventListener(
                "resize",
                () => {
                    clearTimeout(_s.resizeTimer);
                    _s.resizeTimer = setTimeout(function() {
                        _s.onResized();
                    }, 250);
                },
                false
            );

            var v = helper.visible();
            //add if user switch browser tab we pause the game
            document.addEventListener(
                v.event,
                (e) => {
                    if (document.visibilityState == "hidden") {
                        //_s.stop();
                    } else {
                        //_s.restart();
                    }
                },
                false
            );

            //add orientation event
            window.addEventListener(
                "orientationchange",
                (e) => {
                    switch (window.orientation) {
                        case 0:
                            //if (!_s.isOver) _s.restart();
                            break;
                        case 90:
                        case -90:
                            //if (!_s.isOver) _s.stop();
                            break;
                    }
                },
                false
            );

            //chrome fix
            window.addEventListener(
                "wheel",
                (e) => {
                    e.preventDefault();
                }, { passive: false }
            );
        };
        _s.header = function() {
            return document.getElementById("header").getBoundingClientRect();
        };
    }

    window.addEventListener("load", function() {
        var gameWrapper = document.getElementById('game-wrapper');
        var info = gameWrapper.getBoundingClientRect();
        var height = info.height;
        var width = info.width;

        let g = new Game(width, height);
        g.init();

    });
})(window);

Object.defineProperties(PIXI.Sprite.prototype, {
    scaleX: {
        get: function() {
            return this.scale.x;
        },
        set: function(v) {
            this.scale.x = v;
        },
    },
    scaleY: {
        get: function() {
            return this.scale.y;
        },
        set: function(v) {
            this.scale.y = v;
        },
    },
});

//game timer
(function() {
    var game = {};
    game.timer = {
        interval: undefined,
        countFrom: 60, // second
        //count: 
        start: function(c) {
            this.count = this.countFrom = c;
            this.interval = setInterval(this.tick.bind(this), 1000);
        },
        restart: function() {
            if (this.interval) {
                clearInterval(this.interval);
            }
            this.count = this.countFrom;
            this.interval = setInterval((this.tick).bind(this), 1000);
        },
        stop: function() {
            console.log('stop', this.count);
            clearInterval(this.interval);
        },
        tick: function() {
            this.count -= 1;
            if (this.count <= 0) {
                this.count = 0;
                clearInterval(this.interval);
                //game.flow.gameOver();
                console.log('game over');
            }
            // update the view
            //var progress = this.count / this.countFrom * 100;
            //this.progressView.style.width = progress + "%";
        }
    }
    window.timer = game.timer;
})()