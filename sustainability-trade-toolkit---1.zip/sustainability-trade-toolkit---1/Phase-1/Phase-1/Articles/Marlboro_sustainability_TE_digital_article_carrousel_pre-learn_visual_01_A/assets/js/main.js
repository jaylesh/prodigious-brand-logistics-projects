
//https://gist.github.com/spyesx/b58d61f280fae9f2f95a
(function ($) {
    $.fn.hasClassRegEx = function (regex) {
        var classes = $(this).attr('class');

        if (!classes || !regex) { return false; }

        classes = classes.split(' ');
        var len = classes.length;

        for (var i = 0; i < len; i++) {
            if (classes[i].match(regex)) { return { found: true, className: classes[i] } }
        }

        return { found: false, className: null };
    };
})(jQuery);

$(document).on('ready', function () {
    var slider = $(".slider");
    var mainWrapper = $('.main-container');
    var container = $('.container');

    slider.slick(getSliderSettings());

    function getSliderSettings() {
        return {
            dots: true,
            infinite: false,
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false
        }
    }

    classGetter('slide__1-bg');

    //beforeChange
    slider.on('beforeChange', function (event, slick, currentSlide, nextSlide) {
        var currentSlide = nextSlide;
        switch (currentSlide) {
            case 1: return classGetter('slide__2-bg');
            case 2: return classGetter('slide__3-bg');
            default: return classGetter('slide__1-bg');
        }
    });

    //logic class tester
    function classGetter(className) {
        var o = mainWrapper.hasClassRegEx(/slide__+/gm);
        if (o.found) {
            mainWrapper.removeClass(o.className);
            mainWrapper.addClass(className);
        }
    }
});