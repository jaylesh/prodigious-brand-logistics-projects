var cigaretteObj = {
    "2019" : "0",
    "2020" : "15,2",
    "2021" : "3,13",
    "2022" : "5,16",
    "2023" : "6",
    "2024" : "9,17,18",
    "2025" : "10,19",
    "2026" : "11,12,26",
    "2027" : "4,20,21",
    "2028" : "14,22,23",
    "2029" : "1,24,25"
}

var cigaretteToShowArr = [];

$( document ).ready(function() {
    console.log( "ready!", $('h1').width() );

    $('.single-slider').jRange({
        from: 2019,
        to: 2029,
        step: 1,
        scale: [],
        // showScale: true,
        format: '%s',
        width: $('h1').width(),
        showLabels: true,
        snap: false,
        onstatechange:changeFishToCig
    });

});

function changeFishToCig (e) {
    cigaretteToShowArr = [];

    if(e == "2029"){
        $('.animation_text_2029').fadeIn();
        $('.title01').hide()
        $('.title02').fadeIn()
    }else{
        $('.animation_text_2029').fadeOut(200);
        $('.title01').fadeIn()
        $('.title02').hide()
    }

    for (var key in cigaretteObj) {
        if (cigaretteObj.hasOwnProperty(key)) {
            if(parseInt(key) <= parseInt(e)){
                splitArrAndAddToMainArray(cigaretteObj[key]);
            }

        }
    }

    $(".common-fish").css('opacity',1);

    $(".common-cig").each(function(key){

        if(!$(this).hasClass('static-cig')){
            $(this).css('opacity',0);
        }
    });

    cigaretteToShowArr.forEach(function(element) {
        $(".fish"+element).css('opacity',0);
        $(".cig"+element).css('opacity',1);
    });

}

function splitArrAndAddToMainArray(val) {
    var tempArr = val.split(",");

    tempArr.forEach(function(element) {

        cigaretteToShowArr.push(element)
    });
}

$(document).bind(
    'touchmove',
    function(e) {
        e.preventDefault();
    }
);


function preventDefault(e){
    e.preventDefault();
}

function disableScroll(){
    document.body.addEventListener('touchmove', preventDefault, { passive: false });
}
function enableScroll(){
    document.body.removeEventListener('touchmove', preventDefault);
}