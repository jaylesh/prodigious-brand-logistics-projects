window.onload = function(){




    function cig(){
        var cig = new TimelineMax();
 
        cig.to(("#cig1"), 0.5, {ease: Power0.easeOut,opacity:1});
        cig.to(("#cig2"), 0.5, {ease: Power0.easeOut,opacity:1});
        cig.to(("#cig3"), 0.3, {ease: Power0.easeOut,opacity:1});
        cig.to(("#cig4"), 0.3, {ease: Power0.easeOut,opacity:1});
        cig.to(("#cig5"), 0.3, {ease: Power0.easeOut,opacity:1});
        cig.to(("#cig6"), 0.3, {ease: Power0.easeOut,opacity:1});
        return cig;
    }	

var tl = new TimelineMax();
mySplitText = new SplitText(".banner-1 #text_1", {type:"chars"});


tl.to(".banner-1 #text_1", 0, {  opacity:1});
tl.staggerFrom(mySplitText.chars, 0.5, {opacity:0,  ease: SteppedEase.config(1)}, 0.037, "+=0");
tl.to(".banner-1 #text_2-anim", 0.5, { ease: Power1.easeOut, opacity:1, height:30});
tl.to(".banner-1 #cta", 0.5, { ease: Power1.easeOut, scale:1});
tl.add(cig(),"-=3");

}



