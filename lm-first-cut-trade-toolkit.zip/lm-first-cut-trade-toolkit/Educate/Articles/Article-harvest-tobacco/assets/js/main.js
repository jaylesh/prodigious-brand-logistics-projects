$(document).ready(function () {

    //initialize swiper when document ready
    var swiper = new Swiper('.swiper-container', {
        init: true,
        initialSlide: 0,
        direction: 'horizontal',
        effect: 'slide',
        slidesPerView: 1,
        loop: false,
        // resistance:false,
        touchRatio: 1,
        stopOnLastSlide: true,
        allowTouchMove: true,
        uniqueNavElements: true,
        prevSlideMessage: {},

        on: {
            init: function () {

            }
        },

        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev'
        },

        pagination: {
            el: '.swiper-pagination',
            type: 'bullets',
            clickable: true
        }
    });

});
