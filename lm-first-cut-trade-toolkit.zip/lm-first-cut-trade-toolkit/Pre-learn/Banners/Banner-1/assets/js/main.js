window.onload = function(){

    var tl = new TimelineMax();
    var mySplitText_1 = new SplitText("#text-1", {type:"chars"});

    tl.to(".banner-1 #design", 1, { ease: Power1.easeOut, scaleX:2, scaleY:2,left:211, top:110, opacity:1});
    tl.to(".banner-1 #cigarette", 1, { ease: Back.easeOut, scale: 4,transformOrigin: "50% 50%", opacity:1},"-=0.5");
    tl.to(".banner-1 #text-1", 1, { ease: Power1.easeOut, opacity:1},"-=1");
    
    tl.staggerFrom(mySplitText_1.chars, 0.7, {opacity:0, y: '50%', ease:Back.easeOut}, 0.03,"-=0.4");
    tl.to(".banner-1 .line", 1, { ease: Power1.easeOut, opacity:1},"-=1.0");
    tl.to(".banner-1 #firstcut", 1, { ease: Power1.easeOut, opacity:1, left:30},"-=0.5");
    tl.to(".banner-1 #cta", 1, { ease: Power1.easeOut, opacity:1},"+=0.5");
}



