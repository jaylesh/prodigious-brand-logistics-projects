/**
 * class & method here
 */
(function() {
    var SiteEngine = function(container, options) {
        this.container = container;
        this.init(options);
        this.isActivate = false;
    };

    SiteEngine.prototype.init = function(options) {
        this.swiper = new Swiper(this.container, options);
    };

    SiteEngine.prototype.slideNext = function() {
        this.instance().slideNext();
    }

    SiteEngine.prototype.slidePrev = function() {
        this.instance().slidePrev();
    }

    SiteEngine.prototype.gotoSlideNumber = function(number, delay) {
        this.instance().slideTo(number);
    }

    SiteEngine.prototype.hide = function(el, d) {
        gsap.to(el, {
            alpha: 0,
            duration: d != null ? d : 0.35,
            onComplete: function() {
                el.style.visibility = 'hidden';
            }
        });
    }

    SiteEngine.prototype.show = function(el) {
        el.style.visibility = 'visible';
        gsap.to(el, {
            alpha: 1,
            duration: 0.35
        });
    }

    SiteEngine.prototype.blur = function(o) {
        o.forEach(function(e) {
            if (e.blur) classie.add(e.el, 'blur');
            else classie.remove(e.el, 'blur');
        })
    }

    // getter && setters
    SiteEngine.prototype.getContainer = function() {
        return this.container;
    };
    SiteEngine.prototype.instance = function() {
        return document.querySelector(this.container).swiper;
    }
    window.SiteEngine = SiteEngine;

})(window);

function deviceOrientation(w, h) {
    return (h > w) ? 'portrait' : 'landscape';
}

function calculateAspectRatioFit(srcWidth, srcHeight, maxWidth, maxHeight) {
    var ratio = Math.min(maxWidth / srcWidth, maxHeight / srcHeight);
    return {
        width: srcWidth * ratio,
        height: srcHeight * ratio
    };
}

// Image Selector
(function() {
    const MultiImageSelector = function(props) {
        this.container = document.querySelector(props.div);
        this.list = props.list || [];
        this.list = this.shuffle(this.list);
        console.log(props);
    }

    MultiImageSelector.prototype.create = function() {
        //Append element dynamically
    }

    MultiImageSelector.prototype.onImageClick = function(addedClass) {}


    MultiImageSelector.prototype.shuffle = function(array) {
        return utils.shuffle(array);
    }


    window.MultiImageSelector = MultiImageSelector;
})(window);

/**
 * loader
 */
window.addEventListener('load', function() {
    //parent
    const parent = new SiteEngine(".swiper-container-h", {
        allowTouchMove: true,
        direction: 'horizontal',
        nested: true
    })
    const swiper = parent.instance();
    const swipeBtnBegin = (document.querySelector(parent.getContainer())).querySelector('.begin');
    //const swipeBtnNext = (document.querySelector(parent.getContainer())).querySelector('.swiper-button-next--2');

    swipeBtnBegin.addEventListener('click', function(e) {
        swiper.slideTo(this.getAttribute('data-slide-index'));
    })

    swiper.on('slideChange', function() {
        if (this.activeIndex == 0) {

        }
    });

    //swiper V
    const inner = new SiteEngine('.swiper-container-v', {
        allowTouchMove: true,
        direction: 'vertical',
        nested: true
    })
    const swiperV = inner.instance();

    const intense = new MultiImageSelector({
        div: '.game-intense',
        list: []
    });

    const immediate = new MultiImageSelector({
        div: '.game-immediate',
        list: []
    })

    const warm = new MultiImageSelector({
        div: '.game-warm',
        list: []
    })

    swiper.slideTo(1, 0);
});