$(document).ready(function () {

    //initialize swiper when document ready
    var swiper = new Swiper('.swiper-container', {
        pagination: {
            el: '.swiper-pagination',
            type: 'bullets',
            clickable: true
        },
        speed: 400,
        init: true,
        initialSlide: 0,
        direction: 'horizontal',
        setWrapperSize: false,
        autoHeight: false,
        uniqueNavElements: true,
        effect: 'slide',
        slidesPerView: 1,
        mousewheel: true,
        keyboard: true,
        loop: false,
        grabCursor: false,
        touchEventsTarget: 'wrapper',
        touchRatio: 1,
        simulateTouch: true,
        stopOnLastSlide: true,
        allowTouchMove: true,
        shortSwipes: true,
        allowSlidePrev: true,
        centeredSlides: true,
        allowSlideNext: true,
        watchSlidesProgress: true,
        watchSlidesVisibility: true,
        hashNavigation: true,

        on: {
            init: function () {
                console.log('swiper initialized');
            },
        },
    });

    swiper.on('slideChange', function () {
        console.log('slide changed');
    });

    // swiper.ally('nextSlideMessage', function () {
    //     console.log('nextSlideMessage');
    // });
    //
    // swiper.on('prevSlideMessage', function (a11y) {
    //     console.log('prevSlideMessage',a11y.prevSlideMessage);
    // });

    var swiper2 = new Swiper('.swiper-container-2', {
        speed: 400,
        init: true,
        initialSlide: 0,
        direction: 'horizontal',
        setWrapperSize: true,
        autoHeight: false,
        uniqueNavElements: true,
        effect: 'slide',
        slidesPerView: 2,
        mousewheel: true,
        keyboard: true,
        loop: false,
        grabCursor: false,
        touchEventsTarget: 'wrapper',
        touchRatio: 1,
        simulateTouch: true,
        stopOnLastSlide: true,
        allowTouchMove: true,
        shortSwipes: true,

        on: {
            init: function () {
                console.log('swiper initialized');
            },
        },
    });
});