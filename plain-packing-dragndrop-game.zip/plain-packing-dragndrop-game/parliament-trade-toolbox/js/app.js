// cards array holds all cards
let card = document.getElementsByClassName("card");
let cards = [...card];

// deck of all cards in game
const deck = document.getElementById("card-deck");

// declaring move variable
let moves = 0;
let counter = document.querySelector(".moves");

// declare variables for star icons
const stars = document.querySelectorAll(".fa-star");

// declaring variable of matchedCards
let matchedCard = document.getElementsByClassName("match");


 // declare modal
 let modal = document.getElementById("popup1");

 let score = 0;

 // array for opened cards
var openedCards = [];


// @description shuffles cards
function shuffle(array) {
    var currentIndex = array.length, temporaryValue, randomIndex;

    while (currentIndex !== 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }

    return array;
};


// @description shuffles cards when page is refreshed / loads
let btnStart = document.querySelector("button.start-btn");


btnStart.onclick = function fun() {
    var cardDiv = $('.deck');
    cardDiv.find('.card').addClass('open');
    cardDiv.find('.card').addClass('show');
    setTimeout(function(){
        startGame();
        clearInterval(timer);
        timerf(55);
        }, 3000);
    document.querySelector(".intro").style.display = "none";
    document.querySelector(".game").style.display = "flex";
};



// @description function to start a new play 
function startGame(){
 
    // empty the openCards array
    openedCards = [];

    // shuffle deck
    cards = shuffle(cards);
    cards.forEach(function(e,i){
    var cardDiv = $('.deck');
        if(cardDiv.find('.card').hasClass('bg-1')){

            cardDiv.find('.card').removeClass('bg-'+ (i+ 1));
        }
            // do some stuff
            e.classList.add('bg-'+ (i+ 1));

    });

    // remove all exisiting classes from each card
    for (var i = 0; i < cards.length; i++){
        deck.innerHTML = "";
        [].forEach.call(cards, function(item) {
            deck.appendChild(item);
        });
        cards[i].classList.remove("show", "open", "match", "disabled");
    }
    //reset timer
    var timer = document.querySelector(".timer");
    timer.innerHTML = "0 secs";
    counter.innerHTML = "0";
    score =0;

}


// @description toggles open and show class to display cards
var displayCard = function (){

    this.classList.toggle("open");
    this.classList.toggle("show");
    this.classList.toggle("disabled");
    console.log(this.classList)
};


// @description add opened cards to OpenedCards list and check if cards are match or not
function cardOpen() {
    openedCards.push(this);
    var len = openedCards.length;
    if(len === 2){
        // moveCounter();
        if(openedCards[0].type === openedCards[1].type){
            score++;
            counter.innerHTML = score;
            matched();
        } else {
            unmatched();
        }
    }
};


// @description when cards match
function matched(){
    openedCards[0].classList.add("match", "disabled");
    openedCards[1].classList.add("match", "disabled");
    openedCards[0].classList.add("border-match");
    openedCards[1].classList.add("border-match");
    openedCards[0].classList.remove("show", "open", "no-event");
    openedCards[1].classList.remove("show", "open", "no-event");
    var carop =  openedCards[0];
    var carop1 =  openedCards[1];
    setTimeout(function(){
        console.log('here',carop.classList);
        carop.classList.remove("border-match");
        carop1.classList.remove("border-match");
    },1100);


    openedCards = [];
}


// description when cards don't match
function unmatched(){
    openedCards[0].classList.add("unmatched");
    openedCards[1].classList.add("unmatched");
    disable();
    setTimeout(function(){
        openedCards[0].classList.remove("show", "open", "no-event","unmatched");
        openedCards[1].classList.remove("show", "open", "no-event","unmatched");
        enable();
        openedCards = [];
    },1100);
}


// @description disable cards temporarily
function disable(){
    Array.prototype.filter.call(cards, function(card){
        card.classList.add('disabled');
    });
}


// @description enable cards and disable matched cards
function enable(){
    Array.prototype.filter.call(cards, function(card){
        card.classList.remove('disabled');
        for(var i = 0; i < matchedCard.length; i++){
            matchedCard[i].classList.add("disabled");
        }
    });
}







// @description congratulations when all cards match, show modal and moves, time and rating
function congratulations(){
    if (matchedCard.length === document.querySelectorAll(".card").length){
        // modal.classList.add("show");
        setTimeout(function(){
            document.getElementById("popup1").style.opacity = "1";
            document.getElementById("popup1").style.visibility = "visible";
            }, 1000);


    }
}

var timer;
function timerf(sec) {

    timer = setInterval(function () {
        $('.timer').text(sec--+'sec');
        if (sec == -1) {
            closeModal();
            // $('#hideMsg').fadeOut('fast');
            clearInterval(timer);

        }
    }, 1000);
}
// @description close icon on modal
function closeModal(){
    console.log('here')
        document.getElementById("popup2").style.opacity = "1";
        document.getElementById("popup2").style.visibility = "visible";
        modal.classList.remove("show");
        startGame();
        clearInterval(timer);
        timerf(55);
}


// @desciption for user to play Again 
function playAgain(){
    document.getElementById("popup1").style.opacity = "0";
    document.getElementById("popup1").style.visibility = "hidden";
    document.getElementById("popup2").style.opacity = "0";
    document.getElementById("popup2").style.visibility = "hidden";
    modal.classList.remove("show");
    startGame();
    clearInterval(timer);
    timerf(55);

}


// loop to add event listeners to each card
for (var i = 0; i < cards.length; i++){
    card = cards[i];
    card.addEventListener("click", displayCard);
    card.addEventListener("click", cardOpen);
    card.addEventListener("click",congratulations);
};
$('.no').on('click',function () {
    var overlay =   $('.overlay');
    document.querySelector(".intro").style.display = "flex";
    document.querySelector(".game").style.display = "none";
    overlay.css('visibility', 'hidden');
    overlay.css('opacity', '0');
    clearInterval(timer);
    var timertxt = document.querySelector(".timer");
    timertxt.innerHTML = "0 secs";
});

var images = [];
function preload() {
    for (var i = 0; i < arguments.length; i++) {
        images[i] = new Image();
        images[i].src = preload.arguments[i];
    }
}

//-- usage --//
preload(
    "img/1_a.png",
    "img/2_a.png",
    "img/3_a.png",
    "img/4_a.png",
    "img/img_01.png",
    "img/img_02.png",
    "img/img_03.png",
    "img/img_04.png",
    "img/img_05.png",
    "img/img_06.png",
    "img/img_07.png",
    "img/img_08.png",
    "img/prt_01.png",
    "img/prt_02.png",
    "img/prt_03.png",
    "img/prt_04.png",
    "img/prt_05.png",
    "img/prt_06.png",
    "img/prt_07.png",
    "img/prt_08.png",
    "img/golden-dots-small.png",
    "img/golden-dots-bottom.png",
    "img/bg-golden-dots.png",
    "img/background.png"
);
