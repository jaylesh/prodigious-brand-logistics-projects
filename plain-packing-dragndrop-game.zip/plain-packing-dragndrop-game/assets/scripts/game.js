"use strict";
(function(w) {

    function Game(canvas, width, height) {
        this.lists = [];
        this.json = [{
            name: "packaging",
            path: "./assets/img/old-packing-box.png"
        }, {
            name: "front-bad",
            path: "./assets/img/front-image-bad.png"
        }, {
            name: "front-good",
            path: "./assets/img/front-image-good.png"
        }, {
            name: "legal-bad",
            path: "./assets/img/legal-image-bad.png"
        }, {
            name: "legal-good",
            path: "./assets/img/legal-image-good.png"
        }, {
            name: "night-skew-good",
            path: "./assets/img/night-image-skew-good.png"
        }, {
            name: "night-good",
            path: "./assets/img/night-image.png"
        }, {
            name: "right-bad",
            path: "./assets/img/right-image-bad.png"
        }, {
            name: "right-good",
            path: "./assets/img/right-image-good.png"
        }, {
            name: "right-skew-good",
            path: "./assets/img/right-image-skew-good.png"
        }, {
            name: "right-skew-bad",
            path: "./assets/img/right-image-skew-bad.png"
        }, {
            name: "legal-skew-bad",
            path: "./assets/img/legal-image-skew-bad.png"
        }, {
            name: "legal-skew-good",
            path: "./assets/img/legal-image-skew-good.png"
        }, {
            name: "front-skew-bad",
            path: "./assets/img/front-image-skew-bad.png"
        }, {
            name: "front-skew-good",
            path: "./assets/img/front-image-skew-good.png"
        }, ];
        this.datas = [{
                normal: "packaging"
            }, {
                normal: "front-bad",
                skew: "front-skew-bad",
                snap: {
                    x: -540,
                    y: 0.5
                },
                polygon: [0, 20.48, 422.09, 0, 422.59, 773.17, 0.99, 741.8, 0, 20.48],
                origin: {
                    x: 562,
                    y: 0
                },
                color: 0xfe0000,
                isGood: false
            }, //front-bad",
            {
                normal: "front-good",
                skew: "front-skew-good",
                snap: {
                    x: -540,
                    y: -2.6
                },
                polygon: [0.88, 20.7, 424.07, 0, 424.51, 684.33, 0, 658.35, 0.88, 20.7],
                origin: {
                    x: 170,
                    y: 0
                },
                color: 0x00FF00,
                isGood: true
            }, //front-good"
            {
                normal: "legal-bad",
                skew: "legal-skew-bad",
                snap: {
                    x: -540,
                    y: 575
                },
                polygon: [0, 0, 422.87, 19.16, 423.31, 199.27, 1.22, 170.64, 0, 0],
                origin: {
                    x: 562,
                    y: 640
                },
                color: 0xfe0000,
                isGood: false
            }, //legal-bad",
            {
                normal: "legal-good",
                skew: "legal-skew-good",
                snap: {
                    x: -540,
                    y: 580
                },
                polygon: [0, 0, 422.87, 19.16, 423.31, 199.27, 1.22, 170.64, 0, 0],
                origin: {
                    x: 170,
                    y: 650
                },
                color: 0x00FF00,
                isGood: true
            }, //legal-good"
            {
                normal: "night-good",
                skew: "night-skew-good",
                snap: {
                    x: -540,
                    y: 655
                },
                polygon: [0, 0, 420.33, 24.44, 420.55, 120.66, 0.66, 90.06, 0, 0],
                origin: {
                    x: 170,
                    y: 550
                },
                color: 0x00FF00,
                isGood: true
            }, //night-good"
            {
                normal: "right-bad",
                skew: "right-skew-bad",
                snap: {
                    x: -119,
                    y: -1
                },
                polygon: [0.17, 0, 58.62, 17.67, 58.95, 745.43, 0, 775.98, 0.17, 0],
                origin: {
                    x: 22,
                    y: 0
                },
                color: 0xfe0000,
                isGood: false
            }, //right-bad",
            {
                normal: "right-good",
                skew: "right-skew-good",
                snap: {
                    x: -119,
                    y: -1
                },
                polygon: [0.17, 0, 58.62, 17.67, 58.95, 745.43, 0, 775.98, 0.17, 0],
                origin: {
                    x: 960,
                    y: 0
                },
                color: 0x00FF00,
                isGood: true
            } //right-good"
        ];
        this.loader = PIXI.Loader.shared;
        this.app, this.stage, this.gameWidth, this.gameHeight, this.view, this.renderer;
        this.container, this.pContainer, this.oContainer, this.isDragging, this.scale = 0.35;
        this.dragGroup, this.greenGroup;
        this.bump, this.quad, this.squares, this.dropShadow;
        var _ = this;

        this.view = canvas;
        this.gameWidth = width;
        this.gameHeight = height;
        this.currentDragElement;
        this.bump = new Bump(PIXI);
    }
    Game.prototype.init = function() {
        PIXI.utils.skipHello();
        this.preload.bind(this);
        this.build.bind(this);
        this.preload();
    }
    Game.prototype.preload = function() {
        var _ = this;
        this.json.forEach(function(e, i) {
            _.loader.add(e.name, e.path);
        });
        this.loader.load();
        this.loader.onComplete.add(this.complete.bind(this));
    }
    Game.prototype.complete = function() {
        console.log('complete');
        this.build();
        this.addEvent();
    }
    Game.prototype.build = function() {
        this.app = new PIXI.Application({
            width: this.gameWidth,
            height: this.gameHeight,
            view: this.view,
            transparent: true,
            resolution: window.devicePixelRatio || 1,
            resizeTo: window
        });
        this.stage = new PIXI.display.Stage();;
        this.stage.sortableChildren = true;


        this.dropShadow = new PIXI.filters.DropShadowFilter({
            distance: 7,
            alpha: 0.3,
            blur: 2
        });

        this.greenGroup = new PIXI.display.Group(1, true);
        this.greenGroup.sortPriority = 1;
        this.greenGroup.sortableChildren = true;
        this.dragGroup = new PIXI.display.Group(2, true);
        this.dragGroup.sortPriority = 2;
        this.dragGroup.sortableChildren = true;

        this.container = new PIXI.Container();
        //this.container.scale.set(this.scale);
        this.pContainer = new PIXI.Container();
        this.oContainer = new PIXI.Container();
        this.stage.addChild(this.container);
        this.container.addChild(this.pContainer);
        this.container.addChild(this.oContainer);

        this.matchPack = 0;
        this.goodArr = [];

        this.greenGroup.on("sort", function(sprite) {
            sprite.zOrder = 1;
        });

        this.dragGroup.on("sort", function(sprite) {
            sprite.zOrder = 3;
        });

        this.stage.addChild(
            new PIXI.display.Layer(this.greenGroup),
            new PIXI.display.Layer(this.dragGroup)
        );

        this.oContainer.sortableChildren = true;
        this.createSprites();
        this.startGame();

        //debug
        /*this.oContainer.addChild(
            this.debugGraphics(this.oContainer.width, this.oContainer.height)
        );*/
    };


    /**
     * Create sprites
     */
    Game.prototype.createSprites = function() {
        var _ = this;
        this.datas.forEach(function(e, i) {
            const element = new PIXI.Sprite(_.loader.resources[e.normal].texture); //new PIXI.projection.Sprite2d(this.loader.resources[e.name].texture); //new PIXI.Sprite(this.loader.resources[e.name].texture);

            element.name = e.normal;
            element.interactive = true;

            //overlay hover
            var gap = 6;
            const graphic = new PIXI.Graphics();

            //element.addChild(graphic);

            if (element.name === "packaging") {
                _.pContainer.element = element;
                _.pContainer.addChild(element);
            } else {

                //const elementSkew = new PIXI.Sprite(this.loader.resources[e.skew].texture);

                graphic.beginFill(e.color, 0.5);
                graphic.drawPolygon(e.polygon);
                graphic.x = 0;
                graphic.y = 0;
                graphic.endFill();
                graphic.alpha = 0;
                element.isHit = false;
                element.addChild(graphic);
                element.x = e.origin.x; //position.set(e.origin.x, e.origin.y);
                element.y = e.origin.y;
                element.origin = e.origin;
                element.snap = e.snap;
                element.color = e.color;
                element.hover = graphic;
                element.data = e;
                element.convertTo3d();
                element.parentGroup = _.greenGroup;
                //element.anchor.set(0.5);
                element.filters = [_.dropShadow];
                _.addDragInteraction(element);
                _.oContainer.addChild(element);
            }
            //element.scale.set(this.scale);
            _.lists.push({
                mc: element,
                position: e.position
            })
        });
    };

    /**
     * Sprite Drag Events
     */
    Game.prototype.addDragInteraction = function(element) {
        element.interactive = true;
        //element.buttonMode = true;
        element.on("pointerdown", this.onDragStart.bind(this))
            .on("pointerup", this.onDragEnd.bind(this))
            .on("pointerupoutside", this.onDragEnd.bind(this))
            .on("pointermove", this.onDragMove.bind(this));
    }
    Game.prototype.removedDragInteraction = function(element) {
        element.off("pointerdown")
            .off("pointerup")
            .off("pointerupoutside")
            .off("pointermove");
    }
    Game.prototype.onDragStart = function(e) {
        const sprite = e.currentTarget;
        // gsap.to(sprite, 0.5, { scaleX: 0.35, scaleY: 0.35 })
        this.isDragging = true;
        this.currentDragElement = sprite;
        sprite.parentGroup = this.dragGroup;
        var pos = e.data.getLocalPosition(sprite.parent);
    };
    Game.prototype.onDragMove = function(e) {
        if (this.isDragging && this.currentDragElement == e.currentTarget) {
            const sprite = e.currentTarget;
            const newPosition = e.data.getLocalPosition(sprite.parent);
            sprite.x = -(sprite.width / 2) + newPosition.x;
            sprite.y = -(sprite.height / 2) + newPosition.y;
            sprite.updateTransform();
        }
    };
    Game.prototype.onDragEnd = function(e) {
        if (this.isDragging) {
            var _ = this;
            const sprite = e.currentTarget;
            this.isDragging = false;
            gsap.to(sprite, 0.5, {
                //scaleX: 0.35,
                //scaleY: 0.35,
                onComplete: function() {
                    //console.log(sprite.name, " ", sprite.x);
                },
            });

            gsap.to(sprite.hover, 0, {
                alpha: 0
            });
            if (!sprite.isHit) {
                sprite.filters = [this.dropShadow];
                gsap.to(sprite, 0.3, {
                    x: sprite.origin.x,
                    y: sprite.origin.y,
                    onComplete: function() {
                        console.log('nont')
                        sprite.parentGroup = _.greenGroup;
                    }
                });
            } else {
                sprite.isHit = false;

                // if (sprite.name.indexOf('good') >= 0) {
                sprite.filters = [];
                gsap.to(sprite, 0.3, {
                    x: sprite.snap.x,
                    y: sprite.snap.y,
                    onComplete: function() {
                        sprite.parentGroup = _.greenGroup;
                        gsap.to(sprite.hover, 0, {
                            alpha: 0
                        });
                    }
                });

                if (sprite.data.isGood) {
                    // this.matchPack++;
                    this.goodArr.push(sprite.data.normal)
                    this.matchPack = this.goodArr.filter(onlyUnique);


                } else {
                    this.goodArr = [];
                    this.matchPack = 0;
                    var _ = this;
                    document.getElementById("lost").style.zIndex = "10";

                    gsap.to(".outro", 0.3, {
                        opacity: 1
                    });
                    this.lists.forEach(function(el, i) {
                        if (el.mc.name !== 'packaging') {
                            gsap.to(el.mc, {
                                x: el.mc.origin.x,
                                y: el.mc.origin.y,
                                onComplete: function() {
                                    el.mc.texture = _.loader.resources[el.mc.data.normal].texture;
                                    gsap.to(sprite.hover, 0, {
                                        alpha: 0
                                    });
                                }
                            });
                        }
                    })

                    // sprite.x = sprite.origin.x;
                }
                //return;
            }
            this.currentDragElement = null;
        }
    };
    /**
     * Stage Events
     */
    Game.prototype.addEvent = function() {
        this.onStageResize();
        var _ = this;
        var d = debounce(function() {
            _.onStageResize();
        }, 250);
        window.addEventListener("resize", d, false);
    };
    Game.prototype.onStageResize = function() {
        const parent = this.view.parentNode;
        const canvas = this.view;
        let w = parent.clientWidth;
        let h = parent.clientHeight;
        this.gameWidth = w;
        this.gameHeight = h;
        canvas.style.width = w + "px";
        canvas.style.height = h + "px";
        canvas.width = w;
        canvas.height = h;
        this.app.renderer.resize(w, h);

        this.alignSprite();
    };
    Game.prototype.alignSprite = function() {
        // this.container.scale.set(this.gameWidth <= 568 ? 0.2 : this.scale)
        // this.container.scale.set(this.gameWidth >= 900 ? 0.45 : this.scale)
        var _ = this;

        if (this.gameWidth <= 568) {

            this.container.scale.set(0.25)
        } else if (this.gameWidth >= 900) {

            this.container.scale.set(0.45)
        } else {
            this.container.scale.set(0.30)
        }


        this.lists.forEach(function(element, i) {
            var sprite = element.mc;
            var gap = 60;
            if (_.gameWidth > _.gameHeight) { //landscape
                // if (sprite.name === 'packaging') {
                //     this.pContainer.position.set(
                //         gap / 4,
                //         (this.gameHeight - this.pContainer.height) * 0.5);
                // } else {
                //     this.oContainer.position.set(
                //         this.pContainer.x + this.pContainer.width + (gap * 2),
                //         this.pContainer.y);
                // }
                // gsap.to(this.container, 0.5, { alpha: 1 });
                // this.container.position.set(((this.gameWidth) - this.container.width) / 2, 0);
                _.oContainer.x = _.pContainer.width + _.pContainer.x + gap;
                _.oContainer.y = 0;
                _.container.x = (_.gameWidth - _.container.width) / 2;
                _.container.y = (_.gameHeight - _.container.height) / 2;
            } else {
                /*if (sprite.name === 'packaging') {
                    this.pContainer.position.set(
                        (this.gameWidth - this.pContainer.width) * 0.5,
                        gap / 2);
                } else {
                    this.oContainer.position.set(
                        (this.gameWidth - this.oContainer.width) * 0.5,
                        (this.gameHeight - this.oContainer.height) - gap);
                }*/
                // gsap.to(this.container, 0, { alpha: 0 });
                // this.container.position.set(0, 0);
            }
        });
    };

    /**
     * Application Rendering
     */


    Game.prototype.startGame = function() {
        this.app.ticker.stop();
        gsap.ticker.add(this.render.bind(this));
        this.app.ticker.add(this.update.bind(this));
    };
    Game.prototype.stopGame = function() {
        this.app.ticker.stop();
        gsap.ticker.sleep();
    };
    Game.prototype.render = function(delta) {
        this.app.renderer.render(this.stage);
        this.update();

    };
    Game.prototype.update = function() {

        if (this.isDragging) {
            const sprite = this.currentDragElement;
            const hit = this.rectsIntersect(this.currentDragElement, this.pContainer.element);
            if (hit && !sprite.isHit) {
                sprite.isHit = true;
                sprite.isSkew = true
                sprite.texture = this.loader.resources[sprite.data.skew].texture;

                gsap.to(sprite.hover, 0.4, {
                    alpha: 1
                });
            } else if (!hit && sprite.isSkew) {
                gsap.to(sprite.hover, 0, {
                    alpha: 0
                });
                sprite.texture = this.loader.resources[sprite.data.normal].texture;
                sprite.isSkew = false;
                sprite.isHit = false;
            }
        }

        if (this.matchPack.length === 3) {

            setTimeout(function() {
                this.goodArr = [];
                this.matchPack = 0;
                document.querySelector('.congratulation').style.opacity = "1";
                document.querySelector('.congratulation').style.zIndex = "4";
            }, 500);

        }
    };

    Game.prototype.d = function(value) {
        console.log(":::::${value}::::");
    };

    Game.prototype.debugGraphics = function(width, height) {
        var graphic = new PIXI.Graphics();
        graphic.alpha = 0.5;
        graphic.beginFill(0xc34288);
        graphic.drawRect(0, 0, width, height);
        graphic.endFill();
        return graphic;
    };

    Game.prototype.createSquare = function(x, y) {
        const square = new PIXI.Sprite(PIXI.Texture.WHITE);
        square.tint = 0x00FF00;
        square.factor = 1;
        square.anchor.set(0.5);
        square.position.set(x, y);
        return square;
    };

    Game.prototype.skewWiget = function(s) {
        const sprite = s;
        const parent = sprite.parent;
        var x = sprite.x;
        var y = sprite.y;
        var w = sprite.width;
        var h = sprite.height;
        var sx = sprite.scale.x;
        var sy = sprite.scale.y;

        parent.squares = [
            this.createSquare(w / 2 - x, 0),
            this.createSquare(w / 2, 0),
            this.createSquare(w / 2, y * 2),
            this.createSquare(w / 2 - x, y * 2),
        ];

        parent.squares.forEach(function(s) {
            s.parentGroup = _.dragGroup;
            parent.addChild(s);
        });
        parent.quad = parent.squares.map(function(s) {
            s.position
        });
        parent.squares.forEach(function(e) {
            _.addDragInteraction(e);
        });
    }

    Game.prototype.drawShape = function(x, y, w, h) {
        var graphic = new PIXI.Graphics();
        //graphic.clear();
        //graphic.lineStyle(3, 0xff0000, 0.8);
        graphic.beginFill(0x00FF00, 1);
        //graphic.moveTo(x, y);
        graphic.drawRect(x, y, w, h)
        graphic.endFill();
        return graphic;
    }

    Game.prototype.rectsIntersect = function(a, b) {
        var aCircle = a.getBounds();
        var bCircle = b.getBounds();
        return aCircle.x + aCircle.width > bCircle.x &&
            aCircle.x < bCircle.x + bCircle.width &&
            aCircle.y + aCircle.height > bCircle.y &&
            aCircle.y < bCircle.y + bCircle.height;
    };

    w.Game = Game;

})(window);


window.addEventListener('load', function() {
    var gameWrapper = document.getElementById("game-wrapper");
    var info = gameWrapper.getBoundingClientRect();
    var height = info.height;
    var width = info.width;
    var canvas = document.getElementById("game-stage")
    var game = new Game(canvas, width, height);
    // game.init();

    //click play btn
    document.querySelector('.play').addEventListener('click', function() {
        document.querySelector('.intro').style.opacity = "0";
        document.querySelector('.intro').style.zIndex = "0";
        game.init()
    });

    document.querySelector('.txt-try-again').addEventListener('click', function() {
        document.getElementById("lost").style.zIndex = "0";
        gsap.to(".outro", 0.3, {
            opacity: 0
        });
    });
});

Object.defineProperties(PIXI.Sprite.prototype, {
    skewX: {
        get: function() {
            return this.skew.x;
        },
        set: function(v) {
            this.skew.x = v;
        },
    },
    skewY: {
        get: function() {
            return this.skew.y;
        },
        set: function(v) {
            this.skew.y = v;
        },
    },
    scaleX: {
        get: function() {
            return this.scale.x;
        },
        set: function(v) {
            this.scale.x = v;
        },
    },
    scaleY: {
        get: function() {
            return this.scale.y;
        },
        set: function(v) {
            this.scale.y = v;
        },
    },
});

function onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
}