// JavaScript Document

$(document).ready(function(){
    var _questNum = 1;
    var _worldState = "intro";
    var hammertime;
    var ansArray = ["The Netherlands","Germany","Russia","Spain","Switzerland","Czech Republic","Germany","Turkey","UAE","Algeria", "Egypt","France"];
    var imagePath = "src/images/"
    var correctAns = 0;
    var myElement = document.getElementsByClassName('tutorial-screen');
    var imageArr = [];
    var numSequenceGlobe = 31;
    var jsonObj;
    var scaleFull = 1;
    var scaleReduce = 0.6;
    var scalePrize = 0.9;
    var browserHeight = window.innerHeight;
    var prizeBottom = "50%";
    var isLandScape = false;
    var isMobile = false; //initiate as false
    var replay = false;
    var paginationNum = 1;
    var gameStarted = false;


// device detection
    if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent)
        || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0,4))) {
        isMobile = true;
    }


    $(window).on('orientationchange', function(event){
        var h = window.screen.height;
        var w = window.screen.width;
        if(isMobile){

                if(w > h) {
                    console.log('landscape small')

                }else{
                    console.log('portrait small')
                    $('body').css('height',browserHeight+"px");
                }

        }
        else{
            $('body').css('height',browserHeight+"px");
        }


    });

    window.onresize = function(event) {
        browserHeight = window.innerHeight;
        $('body').css('height',browserHeight+"px");
    };

    $(window).trigger('orientationchange');






    if(browserHeight <= 500){
        scaleFull = 0.9;
        scaleReduce = 0.4;
        scalePrize = 0.6;
        prizeBottom = "44%";
    }

    for(var i=1; i<= numSequenceGlobe; i++){
        imageArr.push(imagePath +"world/globe"+ i +'.png');
    }

    for(var i=1; i<= 12; i++){
        imageArr.push(imagePath +"prize/prize-"+ i +'.png');
    }

    //loading images
    var Progress = {
        bar : null,
        index : 0,
        imgList : [],
        init: function(){
            var box = document.getElementById("progressBox");
            var prog = document.createElement("progress");
            box.appendChild(prog);
            this.bar = prog;
        },

        loadImages: function(paths) {
            var self = this,
                i, length = paths.length;
            for (i=0;i<length;i++){
                var img = new Image();
                img.onload = function() {
                    self.increase();
                    if (self.index >= length){
                        self.done();
                    }
                };
                img.src = paths[i];
                this.imgList.push(img);

            }
        },

        increase: function(){
            this.index++;
            var preloaderNUmb = parseInt((100/imageArr.length)*this.index);
            $('.num').text(preloaderNUmb + '%');
            $(".loading-page hr").css("width", preloaderNUmb + "%");

        },

        done : function() {
            // console.log("I am done loading");
            $('.loading-page').hide();
            initQuiz();
        }

    };

    Progress.loadImages(imageArr);

    hammertime = new Hammer(myElement[0]);

    hammertime.get('swipe').set({ direction: Hammer.DIRECTION_HORIZONTAL });





	$(".play-btn").click(function() {
		$(".start-overlay").fadeOut();
        $('.rotate-pic').css("visibility","visible")
        onSwipeAction();
	});

    $(".claim-btn").click(function() {
        $(".btn-block.prize-claim").css("display", "none");
        $(".winner-img").addClass("img-dezoom");
        $(".email-block").fadeIn(2000);
    });

	$('.submit-bt').click(onSubmit);
	$('.continuer-bt').click(onContinueClick);

    addListenerToRadioButton();

    managePaination();
    loadJson();


    // spinGlobe()

    function initQuiz() {
        $('.wrapper').fadeIn();
        gameStarted = true;

    }

    function loadJson() {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                jsonObj = JSON.parse(this.responseText);
                // console.log(jsonObj.hasReward);
            }
        };
        xmlhttp.open("GET", "config.json", true);
        xmlhttp.send();
    }

    function closeGlobe(){
        var topHalf = $('.top-half');
        var prizeContainer = $('.prize-container');

        TweenLite.to(".prize-container", 0.4, { bottom:'18%', scale:scaleReduce, onComplete: function(){
                prizeContainer.hide();

                hammertime.on("swipeleft swiperight", onSwipeAction);

            }});

        TweenLite.to(".top-half", 0.4, { bottom:'50.4%', onComplete: function(){

                //show reward screen
                if(_questNum > 6 && replay == false){
                    chooseWinnerType();
                }
                else if(_questNum > 12 && replay == true){
                    chooseWinnerType();
                }
            }});
    }

    function openGlobe(){
        var prizeContainer = $('.prize-container');

        $('.world-and-prize').show();
        $('.world-pic').hide();

        if(_worldState !='intro'){
            prizeContainer.find('img').attr('src',imagePath+"prize/prize-"+_questNum+".png");
        }

        prizeContainer.show();

        TweenLite.to(".top-half", 1, {bottom:'1000px', onComplete: function(){}}).delay(0.5);
        TweenLite.to(".prize-container", 0.4, { bottom: prizeBottom, scale:scaleFull, opacity:'1',  onComplete: function(){

                if(_worldState !='intro'){
                    showQuestion(_questNum);

                    TweenLite.to(".pagination", 0.3, {opacity:'0'});
                    if(!isLandScape){
                        TweenLite.to(".world-and-prize", 0.4, {scale:scalePrize, marginBottom:'65%', onComplete: function(){}});
                    }
                    else{
                        TweenLite.to(".world-and-prize", 0.4, {marginBottom:'-20%', opacity: 1, onComplete: function(){}});
                    }
                }

            }}).delay(0.5);
    }

    function spinGlobe(direction) {
        var i;
        var intervalImg;
        $('.world-and-prize').hide();
        $('.world-pic').show();
        hammertime.off("swipeleft swiperight", onSwipeAction);

        if(direction == 'swiperight'){
            i = numSequenceGlobe;

            intervalImg = setInterval(function(){
                $('.world-pic').find('img').attr('src','src/images/world/globe'+i+'.png');
                i--;
                if(i<1){
                    clearInterval(intervalImg);
                    openGlobe();
                }
            },40)
        }
        else{
            i = 1;

            intervalImg = setInterval(function(){
                $('.world-pic').find('img').attr('src','src/images/world/globe'+i+'.png');
                i++;
                if(i>numSequenceGlobe){
                    clearInterval(intervalImg);
                    openGlobe();
                }
            },40)
        }




    }

    function onSubmit() {
        checkAnswer();
        hideQuestion();
    }

    function managePaination() {
        var numOfPag = $(".pagination-list ul li").length;


        $( ".pagination-list ul li").removeClass('active')
        for(var i=1; i<=numOfPag; i++){
            if(i<paginationNum){
                $( ".pagination-list ul li:nth-child("+i+")" ).addClass('active');
            }
        }

    }

    function checkAnswer(){
        var radioBtName = "question"+_questNum;
        var ans = $('input[name='+radioBtName+']:checked').val();

        if(ansArray[_questNum-1].toLowerCase() == ans.toLowerCase()){
            $('.ans-holder').removeClass('right').removeClass('wrong').addClass('right');
            $('.wrong-ans').hide();
            $('.right-ans').show();
            correctAns++;
        }
        else {
            $('.ans-holder').removeClass('right').removeClass('wrong').addClass('wrong');
            $('.wrong-ans').show();
            $('.right-ans').hide();
        }

        $('.correct-ans').html(ansArray[_questNum-1]);
    }

    function hideQuestion() {

        TweenLite.to(".question-screen", 0.8, {ease: Expo.easeOut, bottom:-$('.question-screen').height(), onComplete:showResult});
        if(_questNum <= 12) {
            _questNum++;
            paginationNum++
        }

    }

    function showQuestion(questNum){
        _questNum = questNum;

        $('.quest').hide();
        $('.question-'+_questNum).show();
        $('.question-screen').show();

        hammertime.off("swipeleft swiperight", onSwipeAction);

        TweenLite.to(".question-screen", 0.8, {ease: Expo.easeOut, bottom:0});

    }

    function showResult() {
        $('.question-screen').hide();

        $('.result-screen').show();
        $('.radio-bt-holder').removeClass('opt-select');

        TweenLite.to(".result-screen", 0.8, {ease: Expo.easeOut, bottom:0});
    }

    function hideResult() {
        TweenLite.to(".result-screen", 0.8, {ease: Expo.easeOut, bottom:-$('.result-screen').height(), onComplete: function(){$('.result-screen').hide();}});

        managePaination();

    }

    function chooseWinnerType() {
        var winnerDef = "";
        var winnerSrc = "";
        var giftImg = "";
        var giftName = ""
        if(correctAns <=2){
            winnerDef = "First-time Flier";
            winnerSrc = "img02.png";
            giftImg = jsonObj.prize1.image;
            giftName = jsonObj.prize1.prizeName;
        }
        else if(correctAns > 2 && correctAns <=4){
            winnerDef = "Globetrotter";
            winnerSrc = "img01.png";
            giftImg = jsonObj.prize2.image;
            giftName = jsonObj.prize2.prizeName;
        }
        else if(correctAns >= 5){
            winnerDef = "Citizen of the world";
            winnerSrc = "img03.png";
            giftImg = jsonObj.prize3.image;
            giftName = jsonObj.prize3.prizeName;
        }

        hammertime.off("swipeleft swiperight", onSwipeAction);
        TweenLite.to(".pagination", 0.3, {opacity:'0'});
        $('.msg-container').hide();
        $('.congrats .score').html(correctAns+"/6");
        $('.congrats .winner-type').html(winnerDef);
        $('.congrats .winner-img').find('img').attr('src',imagePath + winnerSrc);

        $('.prize .prize-name').html(giftName);
        $('.prize .prize-img').find('img').attr('src',imagePath + giftImg);

        $('.congrats').show();




        if(jsonObj.hasReward.toLowerCase() == "yes"){
            $('.two-btn').show();
            // $('.play-again-btn').hide();
            $('.try-again-btn').off('click');
            $('.get-prize-btn').off('click');

            $('.get-prize-btn').on('click',function(){
                $('.congrats').hide();
                $('.prize').fadeIn();
            });

            $('#inscriptionForm').submit(function(e){
                e.preventDefault();
                console.log("email =",$('.email').val())
                //submit via ajax

                $('.prize').hide();
                $('.pagination').hide();
                $('.thanks').removeClass('hide').fadeIn();
            });

        }
        else{

            $('.get-prize-btn').html("I'M DONE");

            $('.get-prize-btn').on('click',function(){
                $('.congrats').hide();
                $('.pagination').hide();
                $('.thanks').removeClass('hide').fadeIn();
            });
        }

        $('.try-again-btn').on('click',resetQuestion);
        $('.winner-overlay').fadeIn();
    }

    function resetQuestion() {
        $('.winner-overlay').fadeOut();
        paginationNum = 1;
        correctAns = 0;

        if(replay){
            _questNum = 1;
            replay = false;
        }
        else{
            replay = true;
            _questNum = 7;
        }
        TweenLite.to(".pagination", 0.3, {opacity:'1'});
        managePaination();

        for(var i=1; i <=12; i++){
            $('input[name="question'+i+'"]').prop('checked', false);
        }

        $('.submit-bt').removeClass('enable-submit');

        hammertime.on("swipeleft swiperight", onSwipeAction);
    }

    function onContinueClick() {
        hideResult();


        TweenLite.to(".pagination", 0.3, {opacity:'1'});
        if(!isLandScape){
            TweenLite.to(".world-and-prize", 1, {scale:scaleFull, marginBottom:'0', onComplete: function(){
                    closeGlobe();
                }});
        }
        else{
            TweenLite.to(".world-and-prize", 1, {marginBottom:'0', onComplete: function(){
                    closeGlobe();
                }});
        }

    }

    function addListenerToRadioButton () {
        $('.radio-bt-holder input[type=radio]').change(function(e){
            $('.submit-bt-'+_questNum).addClass('enable-submit');
            $('.radio-bt-holder').addClass('opt-select');

        })
    }


    function onSwipeAction(e){


        switch (_worldState) {

            case "intro":

                openGlobe();
                $('.how-to-play-screen').show();
                TweenLite.to(".how-to-play-screen", 0.5, {bottom:'-40px', onComplete: function(){}});
                $('.play-now').click(function(){
                    TweenLite.to(".how-to-play-screen", 0.5, {bottom:'-300px', onComplete: function(){}});
                    _worldState = "tutorial";
                    onSwipeAction();
                });

                break;

            case "tutorial" :
                setTimeout(function(){
                    closeGlobe();
                    $(".rotate-pic").hide();
                    $(".pagination").fadeIn();
                },2000)

                _worldState = "questionTime";
                break;

            case "questionTime":
                spinGlobe(e.type);

                break;

        }
    }
});

