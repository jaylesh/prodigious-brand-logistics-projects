// JavaScript Document
var _questNum = 1;
var _worldState = "intro";
var hammertime;
var ansArray = ["Netherland","Germany","Russia","Spain","Switzerland","Czech Republic","Germany","Turkey","Dubai","Algeria"];
$(document).ready(function(){


    var myElement = document.getElementsByClassName('tutorial-screen');
    hammertime = new Hammer(myElement[0]);

    hammertime.get('swipe').set({ direction: Hammer.DIRECTION_HORIZONTAL });
    hammertime.on("swipeleft swiperight", onSwipeAction);




	$(".play-btn").click(function() {
		$(".overlay-msg").fadeOut();
	});

	$('.submit-bt').click(onSubmit);
	$('.continuer-bt').click(onContinueClick);

    addListenerToRadioButton();
    // showQuestion(2);
    // hideQuestion()
});

function onSubmit() {
    console.log(this.className.split(' ')[0]);
    checkAnswer();
    hideQuestion();
}

function checkAnswer(){
    var radioBtName = "question"+_questNum;
    var ans = $('input[name='+radioBtName+']:checked').val();
    console.log(ans);

    if(ansArray[_questNum-1].toLowerCase() == ans.toLowerCase()){
        $('.ans-holder').removeClass('right').removeClass('wrong').addClass('right');
        $('.wrong-ans').hide();
        $('.right-ans').show();
    }
    else {
        $('.ans-holder').removeClass('right').removeClass('wrong').addClass('wrong');
        $('.wrong-ans').show();
        $('.right-ans').hide();
    }

    $('.correct-ans').html(ansArray[_questNum-1]);
}

function hideQuestion() {

    TweenLite.to(".question-screen", 0.8, {ease: Expo.easeOut, bottom:-$('.question-screen').height(), onComplete:showResult});
    if(_questNum < 10) _questNum++;
}

function showQuestion(questNum){
    _questNum = questNum;

    $('.quest').hide();
    $('.question-'+_questNum).show();
    $('.question-screen').show();

    hammertime.off("swipeleft swiperight", onSwipeAction);

    TweenLite.to(".question-screen", 0.8, {ease: Expo.easeOut, bottom:0});

}

function showResult() {
    $('.question-screen').hide();
    $('.result-screen').show();
    TweenLite.to(".result-screen", 0.8, {ease: Expo.easeOut, bottom:0});
    // TweenLite.to(".result-screen", 0.8, {ease: Expo.easeOut, bottom:-$('.result-screen').height()});
}

function hideResult() {
    hammertime.on("swipeleft swiperight", onSwipeAction);
    TweenLite.to(".result-screen", 0.8, {ease: Expo.easeOut, bottom:-$('.result-screen').height(), onComplete: function(){$('.result-screen').hide();}});
}

function onContinueClick() {
    hideResult();
}

function addListenerToRadioButton () {
    $('.radio-bt-holder input[type=radio]').change(function(e){
        console.log(e.currentTarget.name)
        $('.submit-bt-'+_questNum).addClass('enable-submit');

    })
}


function onSwipeAction(){
    switch (_worldState) {

        case "intro":
            $(".image-01").addClass("hide");
            $(".image-02").removeClass("hide");
            _worldState = "tutorial";
            break;

        case "tutorial" :
            $(".rotate-pic").addClass("hide");
            $(".pagination").removeClass("hide");
            _worldState = "questionTime"
            break;

        case "questionTime":
            showQuestion(_questNum);

            break;

    }
}