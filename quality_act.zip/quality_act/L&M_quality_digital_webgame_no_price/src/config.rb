#compass setting
#require "susy"
#require "normalize-scss"
#require "breakpoint"
#require 'bootstrap-sass'

project_type = :stand_alone
http_path = "/"
css_dir = "css"
sass_dir = "scss/"
images_dir = "images/"
fonts_dir = "fonts/"
javascripts_dir = "scripts"
line_comments = false
preferred_syntax = :scss
output_style = :expanded #:compressed #:expanded
relative_assets = true

gem 'sass', '~> 3.4.0'
sass_options = {:sourcemap => true}