/**
 * class & method here
 */
(function() {
    var SiteEngine = function(container, options) {
        this.container = container;
        this.init(options);
        this.isActivate = false;
    };

    SiteEngine.prototype.init = function(options) {
        this.swiper = new Swiper(this.container, options);
    };

    SiteEngine.prototype.slideNext = function() {
        this.instance().slideNext();
    }

    SiteEngine.prototype.slidePrev = function() {
        this.instance().slidePrev();
    }

    SiteEngine.prototype.hide = function(el, d) {
        gsap.to(el, {
            alpha: 0,
            duration: d != null ? d : 0.35,
            onComplete: function() {
                el.style.visibility = 'hidden';
            }
        });
    }

    SiteEngine.prototype.show = function(el) {
        el.style.visibility = 'visible';
        gsap.to(el, {
            alpha: 1,
            duration: 0.35
        });
    }

    SiteEngine.prototype.blur = function(o) {
        o.forEach(function(e) {
            if (e.blur) classie.add(e.el, 'blur');
            else classie.remove(e.el, 'blur');
        })
    }

    // getter && setters
    SiteEngine.prototype.getContainer = function() {
        return this.container;
    };
    SiteEngine.prototype.instance = function() {
        return document.querySelector(this.container).swiper;
    }
    window.SiteEngine = SiteEngine;

})(window);

(function() {
    var Animator = function() {
        this.animator = gsap.timeline({
            defaults: {
                duration: 0.1,
            }
        });
        this.elements = [];
        this.hasPlayed = false
    }
    Animator.prototype.add = function(o) {
        this.elements.push(o);
    }
    Animator.prototype.play = function() {
        const _ = this;
        this.elements.forEach(function(o, i) {
            _.animator.add(_.create(o), o.d);
        });
        this.animator.play();
        this.hasPlayed = true
    }

    Animator.prototype.reset = function(o) {
        this.elements.forEach(function(o, i) {
            gsap.set(o.set.el, o.set.params);
        })
    }

    Animator.prototype.create = function(o) {
        return gsap.timeline().to(o.el, o.duration, o.params);
    }

    Animator.prototype.instance = function() {
        return this.animator;
    }

    window.Animator = Animator;

})(window);

/**
 * loader
 */
window.addEventListener('load', function() {

    //animator
    const animator = new Animator();
    const animator2 = new Animator();

    //parent
    const parent = new SiteEngine(".swiper-container-main", {
        allowTouchMove: false,
        direction: 'horizontal',
        nested: true
    })
    const swiperParent = parent.instance();
    const swipeBtnPrev = (document.querySelector(parent.getContainer())).querySelector('.swiper-button-prev--2');
    const swipeBtnNext = (document.querySelector(parent.getContainer())).querySelector('.swiper-button-next--2');;

    swipeBtnPrev.addEventListener('click', function() {
        if (!parent.isActivate) return;
        parent.instance().slidePrev();

    });
    swipeBtnNext.addEventListener('click', function() {
        if (!parent.isActivate) return;
        parent.instance().slideNext();
    });

    parent.hide(swipeBtnPrev, 0);
    parent.hide(swipeBtnNext, 0);

    //animations
    //textes
    swiperParent.on('slideChangeTransitionStart', function() {
        parent.isActivate = false;
        parent.blur([{
            el: swipeBtnPrev,
            blur: true
        }, {
            el: swipeBtnNext,
            blur: true
        }]);
        switch (swiperParent.activeIndex) {
            case 1:
                parent.show(swipeBtnPrev);
                parent.show(swipeBtnNext);
                break;
            case 2:
                parent.hide(swipeBtnNext);
                break;
            default:
                parent.hide(swipeBtnPrev);
                parent.hide(swipeBtnNext);
                break;
        }
    })
    swiperParent.on('slideChangeTransitionEnd', function() {
        switch (swiperParent.activeIndex) {
            case 1:
                if (instance != null) {
                    instance.slideTo(0, 0);
                }
                gsap.delayedCall(1.2, function() {
                    animator.play();
                })
                animator2.reset();
                break;
            case 2:
                animator.reset();
                gsap.delayedCall(1.2, function() {
                    animator2.play();
                })

                break;
            default:
                animator.reset();
                animator2.reset();
                break
        }
    });

    //parent.instance().slideTo(1);

    //slide 1
    const slide1 = new SiteEngine(".swiper-container-inner", {
        direction: 'horizontal'
    });

    const startBtn = (document.querySelector(slide1.getContainer())).querySelector('.btn-start');
    startBtn.addEventListener('click', function() {
        parent.slideNext();
    });

    const btnNext = (document.querySelector(slide1.getContainer())).querySelector('.swiper-button-next');
    const instance = slide1.instance();
    instance.on('slideChangeTransitionEnd', function() {
        var islast = instance.activeIndex == instance.slides.length - 1 ? true : false;
        if (islast) {
            classie.add(btnNext, 'hide');
        } else {
            if (classie.has(btnNext, 'hide')) {
                classie.remove(btnNext, 'hide');
            }
        }
    });
    btnNext.addEventListener('click', function() {
        slide1.slideNext();
    });

    //animator for slide 2
    animator.add({
        el: '.screen-2 p',
        duration: 1,
        params: {
            alpha: '0',
            delay: 0.2,
            onComplete: function() {
                parent.blur([{
                    el: swipeBtnPrev,
                    blur: false
                }, {
                    el: swipeBtnNext,
                    blur: false
                }])
                parent.isActivate = true;
            }
        },
        set: {
            el: '.screen-2 p',
            params: {
                alpha: 1
            }
        }
    });
    animator.add({
        el: '.screen-2 .left',
        duration: 1,
        params: {
            x: '-100%',
            //delay: 0.5
        },
        d: "0",
        set: {
            el: '.screen-2 .left',
            params: {
                x: "0"
            }
        }
    });
    animator.add({
        el: '.screen-2 .right',
        duration: 1,
        params: {
            x: '100%',
            //delay: 0.5
        },
        d: "0",
        set: {
            el: '.screen-2 .right',
            params: {
                x: '0'
            }
        }
    });
    animator.add({
        el: '.screen-2 .screen2-image-blur',
        duration: 1,
        params: {
            alpha: 0,
            onComplete: function() {
                //activate buttons
                // removes blur
            }
        },
        d: '-=0.1',
        set: {
            el: '.screen-2 .screen2-image-blur',
            params: {
                alpha: '1'
            }
        }
    });

    //slide 3
    //animator for slide 3
    animator2.add({
        el: '.screen-3 p',
        duration: 1,
        params: {
            alpha: '0',
            delay: 0.2
        },
        set: {
            el: '.screen-3 p',
            params: {
                alpha: 1
            }
        }
    });
    animator2.add({
        el: '.screen-3 .left',
        duration: 1,
        params: {
            x: '-100%',
            //delay: 0.5
        },
        d: "0",
        set: {
            el: '.screen-3 .left',
            params: {
                x: "0"
            }
        }
    });
    animator2.add({
        el: '.screen-3 .right',
        duration: 1,
        params: {
            x: '100%',
            //delay: 0.5
        },
        d: "0",
        set: {
            el: '.screen-3 .right',
            params: {
                x: '0'
            }
        }
    });
    animator2.add({
        el: '.screen-3 .screen3-image-blur',
        duration: 1,
        params: {
            alpha: 0,
            onComplete: function() {
                parent.blur([{
                    el: swipeBtnPrev,
                    blur: false
                }, {
                    el: swipeBtnNext,
                    blur: false
                }])
                parent.isActivate = true;
            }
        },
        d: '-=0.1',
        set: {
            el: '.screen-3 .screen3-image-blur',
            params: {
                alpha: '1'
            }
        }
    })
});